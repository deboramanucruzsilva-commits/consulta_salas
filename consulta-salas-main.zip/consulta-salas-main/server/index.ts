import './env';
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cookieParser from 'cookie-parser';
import { z } from 'zod';
import { requireAdmin, register, login, logout, currentUserResponse, getCurrentUser, sessionSecret } from './auth';
import { ensureAdminFromEnv } from './accounts';
import { readSchedule } from './csv-import';
import { getPool } from './db';
import { ensureSchema } from './migrate';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = express();
const httpServer = createServer(app);
app.disable('x-powered-by');
app.set('trust proxy', 1); // atrás do proxy da hospedagem (Render etc.), para ler o IP real
app.use(cookieParser());
// A importação de planilha aceita corpo maior; exige admin ANTES de ler o corpo.
app.use('/api/admin/import', requireAdmin, express.json({ limit: '2mb' }));
app.use(express.json({ limit: '100kb' }));

const roomSchema = z.object({
  code: z.string().trim().min(1).max(64),
  block: z.string().trim().min(1).max(64),
  roomType: z.string().trim().min(1).max(80),
  capacity: z.number().int().positive().max(500).nullable(),
});
const scheduleSchema = z.object({
  roomId: z.string().uuid(),
  semester: z.string().regex(/^\d{4}\/[12]$/),
  dayOfWeek: z.number().int().min(1).max(6),
  startsAt: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  endsAt: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  professor: z.string().trim().min(1).max(160),
  discipline: z.string().trim().min(1).max(180),
});
const contentSchema = z.object({ title: z.string().trim().min(1).max(240), body: z.string().trim().min(1).max(5000) });
const profileSchema = z.object({
  name: z.string().trim().min(1).max(160),
  occupation: z.enum(['discente', 'docente', 'secretario']),
  registryNumber: z.string().trim().max(80),
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.post('/api/auth/register', register);
app.post('/api/auth/login', login);
app.get('/api/auth/me', (req, res, next) => { void currentUserResponse(req, res, next); });
app.post('/api/auth/logout', logout);

app.get('/api/content', async (_req, res, next) => {
  try {
    const [rows] = await getPool().execute<any[]>('SELECT slug, title, body FROM site_content ORDER BY slug');
    res.json({ content: rows });
  } catch (error) { next(error); }
});

app.get('/api/semesters', async (_req, res, next) => {
  try {
    const [rows] = await getPool().execute<any[]>('SELECT DISTINCT semester FROM class_schedules WHERE published = TRUE ORDER BY semester DESC');
    const published = rows.map((row) => String(row.semester)).filter((value) => /^\d{4}\/[12]$/.test(value));
    const semesters = [...new Set([...published, '2026/2', '2026/1'])].sort((a, b) => b.localeCompare(a, 'pt-BR', { numeric: true }));
    res.json({ semesters });
  } catch (error) { next(error); }
});

app.put('/api/profile', async (req, res, next) => {
  try {
    const user = await getCurrentUser(req);
    if (!user) return res.status(401).json({ error: 'Entre com sua conta para continuar.' });
    const values = profileSchema.parse(req.body);
    await getPool().execute('UPDATE app_users SET name = ?, occupation = ?, registry_number = ? WHERE id = ?', [values.name, values.occupation, values.registryNumber, user.id]);
    const [rows] = await getPool().execute<any[]>('SELECT id, email, name, role, occupation, registry_number FROM app_users WHERE id = ?', [user.id]);
    const row = rows[0];
    res.json({ user: { name: row.name, email: row.email, role: row.role, occupation: row.occupation, registryNumber: row.registry_number } });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Confira os campos do cadastro.' }); next(error); }
});

app.get('/api/room-status', async (req, res, next) => {
  try {
    const semester = z.string().regex(/^\d{4}\/[12]$/).parse(req.query.semester);
    const dayOfWeek = z.coerce.number().int().min(1).max(6).parse(req.query.dayOfWeek);
    const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).parse(req.query.time);
    const [rows] = await getPool().execute<any[]>(
      `SELECT r.id AS roomId, r.code, r.block, r.room_type AS roomType, r.capacity,
        IF(s.id IS NULL, 0, 1) AS occupied, s.professor, s.discipline,
        DATE_FORMAT(s.starts_at, '%H:%i') AS startsAt, DATE_FORMAT(s.ends_at, '%H:%i') AS endsAt
       FROM rooms r
       LEFT JOIN class_schedules s ON s.room_id = r.id AND s.semester = ? AND s.day_of_week = ?
         AND s.starts_at <= ? AND s.ends_at > ? AND s.published = TRUE
       WHERE r.published = TRUE
       ORDER BY r.block, r.code`, [semester, dayOfWeek, time, time],
    );
    const rooms = rows.map((row) => ({ ...row, capacity: row.capacity === null ? null : Number(row.capacity), occupied: Boolean(row.occupied), dayOfWeek }));
    res.json({ rooms, source: rooms.length ? 'published' : 'empty' });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Semestre, dia ou horário inválido.' }); next(error); }
});

app.get('/api/admin/rooms', requireAdmin, async (_req, res, next) => {
  try {
    const [rows] = await getPool().execute<any[]>('SELECT id, code, block, room_type AS roomType, capacity, published FROM rooms ORDER BY block, code');
    res.json({ rooms: rows.map((row) => ({ ...row, capacity: row.capacity === null ? null : Number(row.capacity), published: Boolean(row.published) })) });
  } catch (error) { next(error); }
});

app.post('/api/admin/rooms', requireAdmin, async (req, res, next) => {
  try {
    const values = roomSchema.parse(req.body);
    const id = randomUUID();
    await getPool().execute(
      `INSERT INTO rooms (id, code, block, room_type, capacity, published) VALUES (?, ?, ?, ?, ?, TRUE)
       ON DUPLICATE KEY UPDATE block = VALUES(block), room_type = VALUES(room_type), capacity = VALUES(capacity), published = TRUE`,
      [id, values.code, values.block, values.roomType, values.capacity],
    );
    const [rows] = await getPool().execute<any[]>('SELECT id, code, block, room_type AS roomType, capacity, published FROM rooms WHERE code = ?', [values.code]);
    const row = rows[0];
    res.status(201).json({ room: { ...row, capacity: row.capacity === null ? null : Number(row.capacity), published: Boolean(row.published) } });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Confira a identificação, o bloco, o tipo e a capacidade da sala.' }); next(error); }
});

app.get('/api/admin/schedules', requireAdmin, async (_req, res, next) => {
  try {
    const [rows] = await getPool().execute<any[]>(
      `SELECT s.id, s.room_id AS roomId, r.code AS roomCode, r.block, r.room_type AS roomType,
        s.professor, s.discipline, s.day_of_week AS dayOfWeek,
        DATE_FORMAT(s.starts_at, '%H:%i') AS startsAt, DATE_FORMAT(s.ends_at, '%H:%i') AS endsAt,
        s.semester, s.published
       FROM class_schedules s JOIN rooms r ON r.id = s.room_id ORDER BY s.semester DESC, s.day_of_week, s.starts_at, r.code`,
    );
    res.json({ schedules: rows.map((row) => ({ ...row, dayOfWeek: Number(row.dayOfWeek), published: Boolean(row.published) })) });
  } catch (error) { next(error); }
});

app.post('/api/admin/schedules', requireAdmin, async (req, res, next) => {
  try {
    const values = scheduleSchema.parse(req.body);
    if (values.endsAt <= values.startsAt) return res.status(400).json({ error: 'O horário de término precisa ser posterior ao horário de início.' });
    const user = await getCurrentUser(req);
    const db = getPool();
    const [overlaps] = await db.execute<any[]>(
      `SELECT id FROM class_schedules WHERE room_id = ? AND semester = ? AND day_of_week = ? AND published = TRUE
       AND starts_at < ? AND ends_at > ? LIMIT 1`,
      [values.roomId, values.semester, values.dayOfWeek, values.endsAt, values.startsAt],
    );
    if (overlaps.length) return res.status(409).json({ error: 'Já existe um horário sobreposto para essa sala, dia e semestre.' });
    const id = randomUUID();
    await db.execute(
      `INSERT INTO class_schedules (id, room_id, semester, day_of_week, starts_at, ends_at, professor, discipline, published, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?)`,
      [id, values.roomId, values.semester, values.dayOfWeek, values.startsAt, values.endsAt, values.professor, values.discipline, user?.id ?? null],
    );
    const [rows] = await db.execute<any[]>(
      `SELECT s.id, s.room_id AS roomId, r.code AS roomCode, r.block, r.room_type AS roomType, s.professor, s.discipline,
       s.day_of_week AS dayOfWeek, DATE_FORMAT(s.starts_at, '%H:%i') AS startsAt, DATE_FORMAT(s.ends_at, '%H:%i') AS endsAt,
       s.semester, s.published FROM class_schedules s JOIN rooms r ON r.id=s.room_id WHERE s.id=?`, [id],
    );
    res.status(201).json({ schedule: { ...rows[0], dayOfWeek: Number(rows[0].dayOfWeek), published: Boolean(rows[0].published) } });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Confira sala, semestre, dia, horários, professor e disciplina.' }); next(error); }
});

app.delete('/api/admin/schedules/:id', requireAdmin, async (req, res, next) => {
  try {
    const id = z.string().uuid().parse(req.params.id);
    const [result] = await getPool().execute<any>('DELETE FROM class_schedules WHERE id = ?', [id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Horário não encontrado.' });
    res.json({ ok: true });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Identificador inválido.' }); next(error); }
});

app.post('/api/admin/import', async (req, res, next) => {
  try {
    const { semester, csv } = z.object({ semester: z.string().regex(/^\d{4}\/[12]$/), csv: z.string().min(1) }).parse(req.body);
    const { rows, errors } = readSchedule(csv);
    if (errors.length) return res.status(400).json({ error: 'Corrija a planilha e envie de novo. Nada foi importado.', details: errors.slice(0, 30) });
    if (rows.length > 5000) return res.status(400).json({ error: 'Planilha grande demais (máximo 5000 aulas por envio).' });
    const user = await getCurrentUser(req);
    const db = getPool();
    const roomIds = new Map<string, string>();
    let created = 0;
    const conflicts: string[] = [];
    for (const row of rows) {
      let roomId = roomIds.get(row.code);
      if (!roomId) {
        await db.execute(
          `INSERT INTO rooms (id, code, block, room_type, capacity, published) VALUES (?, ?, ?, ?, ?, TRUE)
           ON DUPLICATE KEY UPDATE block = VALUES(block), room_type = VALUES(room_type), capacity = COALESCE(VALUES(capacity), capacity), published = TRUE`,
          [randomUUID(), row.code, row.block, row.roomType, row.capacity],
        );
        const [found] = await db.execute<any[]>('SELECT id FROM rooms WHERE code = ?', [row.code]);
        roomId = String(found[0].id);
        roomIds.set(row.code, roomId);
      }
      const [overlaps] = await db.execute<any[]>(
        `SELECT id FROM class_schedules WHERE room_id = ? AND semester = ? AND day_of_week = ? AND published = TRUE AND starts_at < ? AND ends_at > ? LIMIT 1`,
        [roomId, semester, row.dayOfWeek, row.endsAt, row.startsAt],
      );
      if (overlaps.length) { conflicts.push(`Linha ${row.line}: ${row.code} já tem aula nesse dia/horário (ignorada).`); continue; }
      await db.execute(
        `INSERT INTO class_schedules (id, room_id, semester, day_of_week, starts_at, ends_at, professor, discipline, published, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE, ?)`,
        [randomUUID(), roomId, semester, row.dayOfWeek, row.startsAt, row.endsAt, row.professor, row.discipline, user?.id ?? null],
      );
      created++;
    }
    res.json({ created, skipped: conflicts.length, rooms: roomIds.size, details: conflicts.slice(0, 30) });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Informe o semestre (ex.: 2026/2) e o conteúdo da planilha.' }); next(error); }
});

app.put('/api/admin/content/:slug', requireAdmin, async (req, res, next) => {
  try {
    const slug = z.enum(['home', 'objetivo', 'como-funciona']).parse(req.params.slug);
    const values = contentSchema.parse(req.body);
    const user = await getCurrentUser(req);
    await getPool().execute('UPDATE site_content SET title = ?, body = ?, updated_by = ? WHERE slug = ?', [values.title, values.body, user?.id ?? null, slug]);
    const [rows] = await getPool().execute<any[]>('SELECT slug, title, body FROM site_content WHERE slug = ?', [slug]);
    if (!rows.length) return res.status(404).json({ error: 'Conteúdo não encontrado.' });
    res.json({ content: rows[0] });
  } catch (error) { if (error instanceof z.ZodError) return res.status(400).json({ error: 'Confira o título e o texto da página.' }); next(error); }
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'Rota de API não encontrada.' }));

if (process.env.NODE_ENV === 'production') {
  const clientPath = path.join(projectRoot, 'dist/client');
  app.use(express.static(clientPath, { maxAge: '1h', index: false }));
  app.get(/.*/, (_req, res) => res.sendFile(path.join(clientPath, 'index.html')));
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    configFile: path.join(projectRoot, 'vite.config.ts'),
    server: { middlewareMode: true, hmr: { server: httpServer }, allowedHosts: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
}

app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Erro de API:', error instanceof Error ? error.message : 'erro não especificado');
  if (!res.headersSent) res.status(500).json({ error: 'Ocorreu um erro interno. Tente novamente mais tarde.' });
});

const port = Number(process.env.PORT || 3000);
try {
  sessionSecret(); // falha cedo se APP_SESSION_SECRET não estiver configurado
  await ensureSchema();
  await ensureAdminFromEnv();
  httpServer.listen(port, '0.0.0.0', () => console.log(`Consulta de Salas ativa na porta ${port}.`));
} catch (error) {
  console.error('O serviço não iniciou porque a base de dados não está pronta:', error instanceof Error ? error.message : 'erro não especificado');
  process.exitCode = 1;
}
