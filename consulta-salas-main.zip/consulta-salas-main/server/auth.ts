import { randomUUID } from 'node:crypto';
import type { Request, Response, NextFunction, RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { getPool } from './db';
import { hashPassword, normalizeEmail, verifyPassword } from './accounts';

// Login próprio por e-mail e senha. A sessão é um JWT assinado com APP_SESSION_SECRET,
// guardado em cookie httpOnly. O papel (user/admin) vem sempre do banco, nunca do cliente.
export type AuthenticatedUser = { id: string; email: string; name: string; role: 'user' | 'admin'; occupation: string; registryNumber: string };

const COOKIE_NAME = 'salas_session';
const SESSION_SECONDS = 7 * 24 * 60 * 60;
const cookieOptions = () => ({ httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', sameSite: 'lax' as const, path: '/' });

export function sessionSecret(): string {
  const secret = process.env.APP_SESSION_SECRET ?? '';
  if (secret.length < 32) throw new Error('APP_SESSION_SECRET ausente ou curto demais (mínimo 32 caracteres). Veja o .env.example.');
  if (secret.startsWith('troque-isto') && process.env.COOKIE_SECURE === 'true') throw new Error('APP_SESSION_SECRET ainda está com o valor de exemplo. Gere um segredo próprio antes de publicar.');
  return secret;
}

const registerSchema = z.object({
  name: z.string().trim().min(1).max(160),
  email: z.string().trim().toLowerCase().email().max(255),
  password: z.string().min(8).max(128),
  occupation: z.enum(['discente', 'docente', 'secretario']),
  registryNumber: z.string().trim().max(80).default(''),
});
const loginSchema = z.object({ email: z.string().trim().toLowerCase().email().max(255), password: z.string().min(1).max(128) });

// Limite simples de tentativas de login (em memória): 10 falhas por e-mail+IP em 15 minutos.
const failures = new Map<string, number[]>();
const WINDOW = 15 * 60 * 1000, MAX_FAILS = 10;
function recentFailures(key: string) {
  const now = Date.now();
  const list = (failures.get(key) ?? []).filter((time) => now - time < WINDOW);
  if (list.length) failures.set(key, list); else failures.delete(key);
  return list;
}

function startSession(res: Response, userId: string) {
  const token = jwt.sign({ uid: userId }, sessionSecret(), { algorithm: 'HS256', expiresIn: SESSION_SECONDS });
  res.cookie(COOKIE_NAME, token, { ...cookieOptions(), maxAge: SESSION_SECONDS * 1000 });
}

const publicUser = (user: AuthenticatedUser) => ({ name: user.name, email: user.email, role: user.role, occupation: user.occupation, registryNumber: user.registryNumber });
const USER_COLUMNS = 'id, email, name, role, occupation, registry_number';
const toUser = (row: any): AuthenticatedUser => ({ id: row.id, email: row.email, name: row.name, role: row.role, occupation: row.occupation, registryNumber: row.registry_number });

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    const values = registerSchema.parse(req.body);
    const db = getPool();
    const [existing] = await db.execute<any[]>('SELECT id FROM app_users WHERE LOWER(email) = ? LIMIT 1', [values.email]);
    if (existing.length) return res.status(409).json({ error: 'Já existe uma conta com este e-mail. Use "Entrar".' });
    const id = randomUUID();
    try {
      await db.execute(
        'INSERT INTO app_users (id, open_id, email, name, occupation, registry_number, role, password_hash) VALUES (?, ?, ?, ?, ?, ?, \'user\', ?)',
        [id, `local:${values.email}`, values.email, values.name, values.occupation, values.registryNumber, await hashPassword(values.password)],
      );
    } catch (error: any) {
      if (error?.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Já existe uma conta com este e-mail. Use "Entrar".' });
      throw error;
    }
    startSession(res, id);
    const [rows] = await db.execute<any[]>(`SELECT ${USER_COLUMNS} FROM app_users WHERE id = ?`, [id]);
    res.status(201).json({ user: publicUser(toUser(rows[0])) });
  } catch (error) {
    if (error instanceof z.ZodError) return res.status(400).json({ error: 'Confira os campos. A senha precisa ter pelo menos 8 caracteres e o e-mail deve ser válido.' });
    next(error);
  }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const values = loginSchema.parse(req.body);
    const key = `${req.ip}|${values.email}`;
    if (recentFailures(key).length >= MAX_FAILS) return res.status(429).json({ error: 'Muitas tentativas. Aguarde alguns minutos e tente de novo.' });
    const [rows] = await getPool().execute<any[]>(`SELECT ${USER_COLUMNS}, password_hash FROM app_users WHERE LOWER(email) = ? LIMIT 1`, [values.email]);
    const row = rows[0];
    const ok = await verifyPassword(values.password, row?.password_hash);
    if (!row || !ok) {
      failures.set(key, [...recentFailures(key), Date.now()]);
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }
    failures.delete(key);
    startSession(res, row.id);
    res.json({ user: publicUser(toUser(row)) });
  } catch (error) {
    if (error instanceof z.ZodError) return res.status(400).json({ error: 'Informe um e-mail válido e a senha.' });
    next(error);
  }
}

export function logout(_req: Request, res: Response) {
  res.clearCookie(COOKIE_NAME, cookieOptions());
  res.json({ ok: true });
}

export async function getCurrentUser(req: Request): Promise<AuthenticatedUser | null> {
  const token = req.cookies?.[COOKIE_NAME];
  if (typeof token !== 'string' || !token) return null;
  try {
    const payload = jwt.verify(token, sessionSecret(), { algorithms: ['HS256'] }) as { uid?: string };
    if (typeof payload.uid !== 'string') return null;
    const [rows] = await getPool().execute<any[]>(`SELECT ${USER_COLUMNS} FROM app_users WHERE id = ? LIMIT 1`, [payload.uid]);
    return rows[0] ? toUser(rows[0]) : null;
  } catch {
    return null;
  }
}

export const requireUser: RequestHandler = async (req, res, next) => {
  try {
    const user = await getCurrentUser(req);
    if (!user) return res.status(401).json({ error: 'Entre com sua conta para continuar.' });
    res.locals.user = user;
    next();
  } catch (error) { next(error); }
};

export const requireAdmin: RequestHandler = (req, res, next) => {
  requireUser(req, res, () => {
    const user = res.locals.user as AuthenticatedUser;
    if (user.role !== 'admin') return res.status(403).json({ error: 'Acesso restrito à administração autorizada.' });
    next();
  });
};

export async function currentUserResponse(req: Request, res: Response, next: NextFunction) {
  try {
    const user = await getCurrentUser(req);
    return res.json({ user: user ? publicUser(user) : null });
  } catch (error) { next(error); }
}
