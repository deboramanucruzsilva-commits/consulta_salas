import './env';
import { closePool, getPool } from './db';
import { ensureSchema } from './migrate';
import { hashPassword, normalizeEmail, upsertAdmin } from './accounts';

const [command, emailArg, password, name] = process.argv.slice(2);
const usage = 'Uso:\n  pnpm admin:create e-mail senha ["Nome"]   cria/promove um administrador\n  pnpm user:password e-mail nova-senha      redefine a senha de uma conta existente';

try {
  if (!['admin', 'password'].includes(command ?? '') || !emailArg || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailArg) || !password || password.length < 8) {
    console.error(usage + '\n(a senha precisa ter pelo menos 8 caracteres)');
    process.exitCode = 2;
  } else {
    await ensureSchema();
    if (command === 'admin') {
      console.log(`Conta administradora ${normalizeEmail(emailArg)}: ${await upsertAdmin(emailArg, password, { name, resetPassword: true })}.`);
    } else {
      const [result] = await getPool().execute<any>('UPDATE app_users SET password_hash = ? WHERE LOWER(email) = ?', [await hashPassword(password), normalizeEmail(emailArg)]);
      if (result.affectedRows) console.log('Senha redefinida.'); else { console.error('Nenhuma conta com esse e-mail.'); process.exitCode = 1; }
    }
  }
} catch (error) {
  console.error('Falhou:', error instanceof Error ? error.message : error);
  process.exitCode = 1;
} finally { await closePool(); }
