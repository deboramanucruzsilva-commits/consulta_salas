import mysql, { type Pool } from 'mysql2/promise';

let pool: Pool | undefined;

export function getPool(): Pool {
  if (pool) return pool;
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL não está disponível para este projeto.');
  const url = new URL(connectionString);
  const useTls = process.env.DATABASE_SSL?.trim().toLowerCase() !== 'false';
  // Provedores com CA própria (ex.: Aiven): cole o certificado em DATABASE_SSL_CA (use \n para quebras de linha).
  const ca = process.env.DATABASE_SSL_CA?.replace(/\\n/g, '\n');
  pool = mysql.createPool({
    host: url.hostname,
    port: Number(url.port || 3306),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: decodeURIComponent(url.pathname.replace(/^\//, '')),
    ssl: useTls ? { minVersion: 'TLSv1.2', rejectUnauthorized: true, ...(ca ? { ca } : {}) } : undefined,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    charset: 'utf8mb4',
  });
  return pool;
}

export async function closePool() {
  if (pool) await pool.end();
  pool = undefined;
}
