// Leitura de planilhas CSV da grade. Colunas aceitas (qualquer ordem, acentos e maiúsculas não importam):
// sala, bloco, tipo, capacidade, dia, inicio, fim, professor, disciplina
export type ImportRow = { line: number; code: string; block: string; roomType: string; capacity: number | null; dayOfWeek: number; startsAt: string; endsAt: string; professor: string; discipline: string };

const plain = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();

export function parseCsv(text: string): string[][] {
  const clean = text.replace(/^\uFEFF/, '');
  const firstLine = clean.split(/\r?\n/, 1)[0] ?? '';
  const delimiter = [';', '\t', ','].map((d) => [d, firstLine.split(d).length] as const).sort((a, b) => b[1] - a[1])[0][0];
  const rows: string[][] = [];
  let row: string[] = [], cell = '', quoted = false;
  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (quoted) {
      if (ch === '"' && clean[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === delimiter) { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && clean[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.some((value) => value.trim() !== '')) rows.push(row); else rows.push([]);
      row = [];
    } else cell += ch;
  }
  row.push(cell);
  if (row.some((value) => value.trim() !== '')) rows.push(row);
  return rows; // linhas vazias viram [] para preservar a numeração
}

const aliases: Record<string, string> = {
  sala: 'code', codigo: 'code', bloco: 'block', tipo: 'roomType', capacidade: 'capacity', dia: 'day', diadasemana: 'day',
  inicio: 'start', horarioinicio: 'start', fim: 'end', termino: 'end', horariofim: 'end', professor: 'professor', docente: 'professor', disciplina: 'discipline',
};
const days: Record<string, number> = { seg: 1, ter: 2, qua: 3, qui: 4, sex: 5, sab: 6 };

function parseTime(value: string): string | null {
  const match = value.trim().match(/^(\d{1,2})(?::|h)(\d{2})$/i);
  if (!match) return null;
  const [h, m] = [Number(match[1]), Number(match[2])];
  return h < 24 && m < 60 ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}` : null;
}

export function readSchedule(text: string): { rows: ImportRow[]; errors: string[] } {
  const table = parseCsv(text);
  const errors: string[] = [];
  const headerIndex = table.findIndex((r) => r.length);
  if (headerIndex < 0) return { rows: [], errors: ['O arquivo está vazio.'] };
  const columns: Record<string, number> = {};
  table[headerIndex].forEach((name, index) => { const key = aliases[plain(name).replace(/[^a-z]/g, '')]; if (key && !(key in columns)) columns[key] = index; });
  const missing = ['code', 'day', 'start', 'end', 'professor', 'discipline'].filter((key) => !(key in columns));
  if (missing.length) {
    const labels: Record<string, string> = { code: 'sala', day: 'dia', start: 'inicio', end: 'fim', professor: 'professor', discipline: 'disciplina' };
    return { rows: [], errors: [`Faltam colunas no cabeçalho: ${missing.map((k) => labels[k]).join(', ')}. A primeira linha deve ser o cabeçalho.`] };
  }
  const rows: ImportRow[] = [];
  for (let i = headerIndex + 1; i < table.length; i++) {
    const cells = table[i];
    if (!cells.length) continue;
    const line = i + 1;
    const get = (key: string) => (key in columns ? (cells[columns[key]] ?? '').trim() : '');
    const code = get('code'), professor = get('professor'), discipline = get('discipline');
    const dayRaw = get('day'); const dayNumber = Number(dayRaw);
    const dayOfWeek = Number.isInteger(dayNumber) && dayNumber >= 1 && dayNumber <= 6 ? dayNumber : days[plain(dayRaw).slice(0, 3)];
    const startsAt = parseTime(get('start')), endsAt = parseTime(get('end'));
    const capacityRaw = get('capacity'); const capacity = capacityRaw ? Number(capacityRaw) : null;
    const problems: string[] = [];
    if (!code || code.length > 64) problems.push('sala vazia ou longa demais');
    if (!professor || professor.length > 160) problems.push('professor vazio ou longo demais');
    if (!discipline || discipline.length > 180) problems.push('disciplina vazia ou longa demais');
    if (!dayOfWeek) problems.push(`dia inválido "${dayRaw}" (use segunda a sábado ou 1 a 6)`);
    if (!startsAt) problems.push(`horário de início inválido "${get('start')}" (use HH:MM)`);
    if (!endsAt) problems.push(`horário de fim inválido "${get('end')}" (use HH:MM)`);
    if (startsAt && endsAt && endsAt <= startsAt) problems.push('o fim precisa ser depois do início');
    if (capacity !== null && (!Number.isInteger(capacity) || capacity < 1 || capacity > 500)) problems.push('capacidade inválida');
    if (problems.length) { errors.push(`Linha ${line}: ${problems.join('; ')}.`); continue; }
    const block = get('block') || (code.includes('-') ? code.split('-')[0] : code.slice(0, 1)).toUpperCase();
    rows.push({ line, code, block: block.slice(0, 64), roomType: (get('roomType') || 'Sala de aula').slice(0, 80), capacity, dayOfWeek: dayOfWeek!, startsAt: startsAt!, endsAt: endsAt!, professor, discipline });
  }
  if (!rows.length && !errors.length) errors.push('Nenhuma aula encontrada abaixo do cabeçalho.');
  return { rows, errors };
}
