import './env';
import { closePool, getPool } from './db';

export async function ensureSchema() {
  const db = getPool();
  await db.query(`
    CREATE TABLE IF NOT EXISTS app_users (
      id CHAR(36) NOT NULL PRIMARY KEY,
      open_id VARCHAR(191) NOT NULL UNIQUE,
      email VARCHAR(255) NOT NULL,
      password_hash VARCHAR(255) NULL,
      name VARCHAR(160) NOT NULL DEFAULT '',
      occupation ENUM('discente','docente','secretario') NOT NULL DEFAULT 'discente',
      registry_number VARCHAR(80) NOT NULL DEFAULT '',
      role ENUM('user','admin') NOT NULL DEFAULT 'user',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_app_users_email (email)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  // Bancos criados antes do login por senha não têm esta coluna.
  const [cols] = await db.query(`SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'app_users' AND COLUMN_NAME = 'password_hash'`) as any;
  if (!cols.length) await db.query('ALTER TABLE app_users ADD COLUMN password_hash VARCHAR(255) NULL');
  await db.query(`
    CREATE TABLE IF NOT EXISTS rooms (
      id CHAR(36) NOT NULL PRIMARY KEY,
      code VARCHAR(64) NOT NULL UNIQUE,
      block VARCHAR(64) NOT NULL,
      room_type VARCHAR(80) NOT NULL,
      capacity INT NULL,
      published BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_rooms_published_block (published, block)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS class_schedules (
      id CHAR(36) NOT NULL PRIMARY KEY,
      room_id CHAR(36) NOT NULL,
      semester VARCHAR(16) NOT NULL,
      day_of_week TINYINT UNSIGNED NOT NULL,
      starts_at TIME NOT NULL,
      ends_at TIME NOT NULL,
      professor VARCHAR(160) NOT NULL,
      discipline VARCHAR(180) NOT NULL,
      published BOOLEAN NOT NULL DEFAULT TRUE,
      created_by CHAR(36) NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_schedule_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT,
      INDEX idx_schedule_slot (semester, day_of_week, starts_at, ends_at, published),
      INDEX idx_schedule_room (room_id, semester)
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS site_content (
      slug VARCHAR(32) NOT NULL PRIMARY KEY,
      title VARCHAR(240) NOT NULL,
      body TEXT NOT NULL,
      updated_by CHAR(36) NULL,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
  `);

  const defaults = [
    ['home', 'Encontre a sala da sua disciplina na grade do semestre.', 'Consulte a sala vinculada a cada aula e veja os horários de ocupação previstos a partir da grade semestral publicada pela faculdade.'],
    ['objetivo', 'Informação de sala, clara e fácil de consultar.', 'O projeto reúne em um só lugar as informações de salas, disciplinas, professores e horários da grade publicada para facilitar a rotina no campus.'],
    ['como-funciona', 'Uma consulta simples, baseada na grade publicada.', 'As informações são organizadas por semestre e atualizadas pela administração. Pesquise por sala, professor ou disciplina e confira o horário previsto.'],
  ];
  for (const [slug, title, body] of defaults) {
    await db.execute('INSERT IGNORE INTO site_content (slug, title, body) VALUES (?, ?, ?)', [slug, title, body]);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  ensureSchema().then(async () => {
    console.log('Esquema criado ou já atualizado.');
    await closePool();
  }).catch(async (error) => {
    console.error('Falha ao executar migrações:', error instanceof Error ? error.message : error);
    await closePool().catch(() => undefined);
    process.exitCode = 1;
  });
}
