import { randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { getPool } from './db';

// Hash de senha com scrypt (nativo do Node, sem dependências extras).
// Formato guardado no banco: scrypt$N$r$p$salt(base64)$hash(base64)
const N = 16384, R = 8, P = 1, KEYLEN = 64;

function derive(password: string, salt: Buffer, n = N, r = R, p = P): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, KEYLEN, { N: n, r, p, maxmem: 128 * n * r * 2 }, (error, key) => (error ? reject(error) : resolve(key)));
  });
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await derive(password, salt);
  return ['scrypt', N, R, P, salt.toString('base64'), key.toString('base64')].join('$');
}

export async function verifyPassword(password: string, stored: string | null | undefined): Promise<boolean> {
  // Mesmo sem hash válido, executa o cálculo para manter o tempo de resposta parecido.
  const parts = (stored ?? '').split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') {
    await derive(password, Buffer.alloc(16));
    return false;
  }
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, 'base64');
  const actual = await derive(password, Buffer.from(salt, 'base64'), Number(n), Number(r), Number(p));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export const normalizeEmail = (email: string) => email.trim().toLowerCase();

/** Cria (ou atualiza) uma conta administradora. Só troca a senha de uma conta existente se resetPassword = true. */
export async function upsertAdmin(email: string, password: string, options: { name?: string; resetPassword?: boolean } = {}) {
  const db = getPool();
  const mail = normalizeEmail(email);
  const [rows] = await db.execute<any[]>('SELECT id, password_hash FROM app_users WHERE LOWER(email) = ? LIMIT 1', [mail]);
  if (rows.length) {
    const needsPassword = !rows[0].password_hash || options.resetPassword;
    if (needsPassword) {
      await db.execute('UPDATE app_users SET role = \'admin\', password_hash = ? WHERE id = ?', [await hashPassword(password), rows[0].id]);
      return 'atualizada (senha definida)';
    }
    await db.execute('UPDATE app_users SET role = \'admin\' WHERE id = ?', [rows[0].id]);
    return 'já existia (papel de administrador garantido, senha mantida)';
  }
  await db.execute(
    'INSERT INTO app_users (id, open_id, email, name, role, password_hash) VALUES (?, ?, ?, ?, \'admin\', ?)',
    [randomUUID(), `local:${mail}`, mail, options.name ?? 'Administrador', await hashPassword(password)],
  );
  return 'criada';
}

/** Chamado na inicialização: se ADMIN_EMAIL e ADMIN_PASSWORD estiverem definidos, garante essa conta de admin. */
export async function ensureAdminFromEnv() {
  const { ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_RESET_PASSWORD } = process.env;
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD) return;
  if (ADMIN_PASSWORD.length < 8) { console.error('ADMIN_PASSWORD precisa ter pelo menos 8 caracteres; conta admin não criada.'); return; }
  const result = await upsertAdmin(ADMIN_EMAIL, ADMIN_PASSWORD, { resetPassword: ADMIN_RESET_PASSWORD === 'true' });
  console.log(`Conta administradora ${normalizeEmail(ADMIN_EMAIL)}: ${result}.`);
}
