import { useEffect, useState } from 'react';
import { ArrowRight, BookOpen, CalendarDays, Check, Clock3, Search, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Brand, SiteHeader } from '../components/SiteHeader';
import { api, type SiteContent } from '../lib/api';

type PageKind = 'home' | 'objective' | 'how';
type ContentSlug = 'home' | 'objetivo' | 'como-funciona';

const defaults: Record<ContentSlug, SiteContent> = {
  home: {
    slug: 'home',
    title: 'Encontre a sala da sua disciplina na grade do semestre.',
    body: 'Consulte a sala vinculada a cada aula e veja os horários de ocupação previstos a partir da grade semestral publicada pela faculdade.',
  },
  objetivo: {
    slug: 'objetivo',
    title: 'Informação de sala, clara e fácil de consultar.',
    body: 'O projeto reúne em um só lugar as informações de salas, disciplinas, professores e horários da grade publicada para facilitar a rotina no campus.',
  },
  'como-funciona': {
    slug: 'como-funciona',
    title: 'Uma consulta simples, baseada na grade publicada.',
    body: 'As informações são organizadas por semestre e atualizadas pela administração. Pesquise por sala, docente ou disciplina e confira o horário previsto.',
  },
};

function useContent(slug: ContentSlug) {
  const [content, setContent] = useState(defaults[slug]);
  useEffect(() => {
    let active = true;
    api.content().then(({ content: entries }) => {
      const match = entries.find((item) => item.slug === slug);
      if (active && match) setContent(match);
    }).catch(() => undefined);
    return () => { active = false; };
  }, [slug]);
  return content;
}

export function InformationPage({ kind }: { kind: PageKind }) {
  const slug = kind === 'home' ? 'home' : kind === 'objective' ? 'objetivo' : 'como-funciona';
  const content = useContent(slug);

  return (
    <div className="marketing-page">
      <SiteHeader active={kind === 'home' ? 'home' : kind === 'objective' ? 'objetivo' : 'como funciona'} />
      {kind === 'home' ? (
        <>
          <main className="home-main">
            <section className="hero-section">
              <div className="hero-copy">
                <div className="eyebrow"><span className="eyebrow-dot" /> UNIFEI · ITABIRA</div>
                <h1>{content.title}</h1>
                <p className="hero-description">{content.body}</p>
                <div className="hero-actions">
                  <Link className="button button-primary button-large" to="/painel">Consultar salas <ArrowRight size={18} /></Link>
                  <Link className="button button-outline button-large" to="/como-funciona">Como funciona</Link>
                </div>
                <p className="quiet-note"><Clock3 size={15} /> Consulta da grade do semestre. Sem rastreamento em tempo real.</p>
              </div>
              <div className="hero-art" aria-label="Resumo ilustrativo da consulta semestral">
                <div className="hero-illustration-top"><span className="mini-icon"><CalendarDays size={19} /></span><span>GRADE SEMESTRAL</span><span className="sample-chip">2026/2 · exemplo</span></div>
                <div className="hero-preview-title">Ocupação das salas</div>
                <div className="hero-preview-subtitle">Horário selecionado · quarta-feira</div>
                <div className="hero-metric-row">
                  <div className="hero-metric"><span>Total de salas</span><strong>27</strong></div>
                  <div className="hero-metric"><span>Livres</span><strong>09</strong></div>
                  <div className="hero-metric"><span>Ocupadas</span><strong>18</strong></div>
                </div>
                <div className="hero-preview-search"><Search size={17} /><span>Buscar sala, professor ou disciplina</span></div>
                <div className="hero-preview-foot"><span className="status-dot status-dot-free" /> Salas e horários conforme a grade publicada</div>
                <div className="hero-stamp"><ShieldCheck size={16} /> Dados atualizados pela administração</div>
              </div>
            </section>
            <section className="home-info-strip" aria-label="Como o portal ajuda">
              <article><span className="info-icon"><Search size={20} /></span><div><h2>Encontre rapidamente</h2><p>Pesquise por sala, docente ou disciplina.</p></div></article>
              <article><span className="info-icon"><CalendarDays size={20} /></span><div><h2>Consulte a grade</h2><p>Veja os horários previstos para o semestre.</p></div></article>
              <article><span className="info-icon"><ShieldCheck size={20} /></span><div><h2>Informação organizada</h2><p>As atualizações são publicadas pela administração.</p></div></article>
            </section>
            <section className="home-callout">
              <div><div className="eyebrow">TRANSPARÊNCIA SOBRE OS DADOS</div><h2>Não é um rastreador de pessoas.</h2><p>O portal consulta a grade de aulas preparada para o semestre. Ele não acompanha a localização de professores nem confirma ocupação ao vivo.</p></div>
              <Link className="text-link" to="/objetivo">Conheça o objetivo <ArrowRight size={17} /></Link>
            </section>
          </main>
          <Footer />
        </>
      ) : (
        <>
          <main className="info-main">
            <div className="info-heading">
              <div className="eyebrow"><span className="eyebrow-dot" /> PAINEL DE OCUPAÇÃO DE SALAS</div>
              <h1>{content.title}</h1>
              <p>{content.body}</p>
            </div>
            {kind === 'objective' ? (
              <section className="objective-layout">
                <div className="objective-card objective-card-blue">
                  <span className="objective-symbol"><BookOpen size={25} /></span>
                  <h2>Uma referência para a rotina no campus</h2>
                  <p>O painel ajuda a localizar a sala associada a uma aula e a consultar a ocupação planejada em determinado horário, usando as informações divulgadas para o semestre.</p>
                </div>
                <div className="objective-side">
                  <div className="objective-note"><span>01</span><div><strong>Consulte a programação</strong><p>As informações refletem a grade semestral publicada.</p></div></div>
                  <div className="objective-note"><span>02</span><div><strong>Pesquise do seu jeito</strong><p>Use sala, professor, disciplina, bloco, tipo ou status.</p></div></div>
                  <div className="objective-note"><span>03</span><div><strong>Atualização administrativa</strong><p>A edição dos dados é restrita aos administradores autorizados.</p></div></div>
                </div>
              </section>
            ) : (
              <section className="how-steps">
                <article className="step-card"><span className="step-number">01</span><span className="step-icon"><CalendarDays size={22} /></span><h2>A grade é publicada</h2><p>A administração disponibiliza a programação de aulas e salas do semestre.</p></article>
                <article className="step-card"><span className="step-number">02</span><span className="step-icon"><Search size={22} /></span><h2>Você faz a busca</h2><p>Pesquise uma sala, professor ou disciplina e refine por horário, bloco ou tipo.</p></article>
                <article className="step-card"><span className="step-number">03</span><span className="step-icon"><Check size={22} /></span><h2>Confira a previsão</h2><p>Veja a ocupação prevista de acordo com a grade publicada para aquele período.</p></article>
              </section>
            )}
            <div className="notice-card"><Clock3 size={19} /><p>As informações representam a grade semestral publicada e <strong>não acompanham professores em tempo real</strong>.</p></div>
            <Link className="button button-primary button-large info-cta" to="/painel">Consultar salas <ArrowRight size={17} /></Link>
          </main>
          <Footer />
        </>
      )}
    </div>
  );
}

function Footer() {
  return <footer className="site-footer"><Brand compact /><span>UNIFEI - Itabira <span className="footer-divider">·</span> Consulta baseada na grade semestral</span><Link to="/como-funciona">Como funciona</Link></footer>;
}
