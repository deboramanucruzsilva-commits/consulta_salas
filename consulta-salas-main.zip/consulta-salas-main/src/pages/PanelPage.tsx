import { useEffect, useMemo, useState } from 'react';
import { CalendarDays, ChevronDown, Clock3, Filter, RefreshCw, Search, SlidersHorizontal } from 'lucide-react';
import { SiteHeader } from '../components/SiteHeader';
import { api, type RoomStatus } from '../lib/api';

const demoRooms: RoomStatus[] = [
  { roomId: 'd1', code: 'E-201', block: 'E', roomType: 'Sala de aula', capacity: 40, occupied: true, professor: 'Prof. Exemplo', discipline: 'Cálculo I', dayOfWeek: 3, startsAt: '14:00', endsAt: '15:40' },
  { roomId: 'd2', code: 'E-202', block: 'E', roomType: 'Sala de aula', capacity: 35, occupied: false, professor: null, discipline: null },
  { roomId: 'd3', code: 'F-105', block: 'F', roomType: 'Laboratório', capacity: 28, occupied: true, professor: 'Profa. Demonstração', discipline: 'Prática de laboratório', dayOfWeek: 3, startsAt: '14:00', endsAt: '16:00' },
  { roomId: 'd4', code: 'F-106', block: 'F', roomType: 'Sala de aula', capacity: 32, occupied: false, professor: null, discipline: null },
  { roomId: 'd5', code: 'G-101', block: 'G', roomType: 'Sala de aula', capacity: 45, occupied: true, professor: 'Prof. Exemplo', discipline: 'Álgebra Linear', dayOfWeek: 3, startsAt: '14:00', endsAt: '15:40' },
  { roomId: 'd6', code: 'G-202', block: 'G', roomType: 'Laboratório', capacity: 24, occupied: true, professor: 'Profa. Demonstração', discipline: 'Sistemas Digitais', dayOfWeek: 3, startsAt: '14:00', endsAt: '15:40' },
  { roomId: 'd7', code: 'H-001', block: 'H', roomType: 'Auditório', capacity: 90, occupied: false, professor: null, discipline: null },
  { roomId: 'd8', code: 'H-104', block: 'H', roomType: 'Sala de aula', capacity: 38, occupied: true, professor: 'Prof. Exemplo', discipline: 'Introdução à Computação', dayOfWeek: 3, startsAt: '14:00', endsAt: '15:40' },
];

const days = [{ label: 'Segunda-feira', value: 1 }, { label: 'Terça-feira', value: 2 }, { label: 'Quarta-feira', value: 3 }, { label: 'Quinta-feira', value: 4 }, { label: 'Sexta-feira', value: 5 }, { label: 'Sábado', value: 6 }];
const timeFormat = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

export function PanelPage() {
  const [semester, setSemester] = useState('2026/2');
  const [semesters, setSemesters] = useState<string[]>(['2026/2', '2026/1']);
  const [dayOfWeek, setDayOfWeek] = useState(3);
  const [time, setTime] = useState('14:35');
  const [timeInput, setTimeInput] = useState('14:35');
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [block, setBlock] = useState('');
  const [status, setStatus] = useState('');
  const [publishedRooms, setPublishedRooms] = useState<RoomStatus[] | null>(null);
  const [updated, setUpdated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');

  const load = async () => {
    setLoading(true);
    setUpdated(false);
    try {
      const result = await api.roomStatus({ semester, dayOfWeek, time });
      setPublishedRooms(result.rooms);
      setApiError('');
    } catch {
      setPublishedRooms(null);
      setApiError('Não foi possível conectar aos dados oficiais. A prévia abaixo é apenas demonstrativa.');
    } finally { setLoading(false); setUpdated(true); }
  };

  useEffect(() => { void load(); }, [semester, dayOfWeek, time]);

  useEffect(() => {
    let active = true;
    void api.semesters().then(({ semesters: published }) => {
      if (!active) return;
      const options = [...new Set(['2026/2', '2026/1', ...published])].sort((a, b) => b.localeCompare(a, 'pt-BR', { numeric: true }));
      setSemesters(options);
      if (!options.includes(semester)) setSemester(options[0] ?? '2026/2');
    }).catch(() => {});
    return () => { active = false; };
  }, []);

  // Dados de demonstração só aparecem se a API falhar. Banco vazio mostra aviso de "nenhuma sala", sem números inventados.
  const sourceIsDemo = publishedRooms === null;
  const rooms = publishedRooms ?? demoRooms;
  const visibleRooms = useMemo(() => rooms.filter((room) => {
    const term = search.trim().toLocaleLowerCase('pt-BR');
    const matchSearch = !term || [room.code, room.professor ?? '', room.discipline ?? ''].some((value) => value.toLocaleLowerCase('pt-BR').includes(term));
    const matchType = !type || room.roomType === type;
    const matchBlock = !block || room.block === block;
    const matchStatus = !status || (status === 'Ocupada' ? room.occupied : !room.occupied);
    return matchSearch && matchType && matchBlock && matchStatus;
  }), [rooms, search, type, block, status]);
  const totalRooms = rooms.length;
  const occupiedRooms = rooms.filter((room) => room.occupied).length;
  const freeRooms = totalRooms - occupiedRooms;

  return (
    <div className="application-page">
      <SiteHeader compact active="consultar salas" />
      <main className="panel-main">
        <section className="panel-heading-row">
          <div><div className="eyebrow"><span className="eyebrow-dot" /> CONSULTA SEMESTRAL</div><h1>Ocupação das salas</h1><p className="panel-subtitle">Consulte a previsão para a grade publicada do semestre.</p></div>
          <div className="panel-toolbar">
            <label className="semester-select"><CalendarDays size={17} /><select aria-label="Semestre" value={semester} onChange={(event) => setSemester(event.target.value)}>{semesters.map((value) => <option key={value} value={value}>{value} · {value.endsWith('/1') ? '1º' : '2º'} semestre</option>)}</select><ChevronDown size={15} /></label>
            <button type="button" className="button button-primary button-refresh" onClick={() => void load()} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''} /> {loading ? 'Atualizando…' : 'Atualizar'}</button>
          </div>
        </section>
        <div className="selected-period"><CalendarDays size={15} /><span>{days.find((day) => day.value === dayOfWeek)?.label}, {time}</span><span className="period-divider">·</span><span>horário selecionado na grade</span></div>
        <section className="metrics-grid" aria-label="Resumo da ocupação">
          <Metric label="Total de salas" value={totalRooms} icon={<SlidersHorizontal size={17} />} />
          <Metric label="Livres" value={freeRooms} icon={<span className="status-dot status-dot-free" />} tone="free" />
          <Metric label="Ocupadas" value={occupiedRooms} icon={<span className="status-dot status-dot-busy" />} tone="busy" />
        </section>
        {sourceIsDemo && <div className="demo-notice"><span className="demo-chip">Demonstração</span><p>{apiError || 'Os números e exemplos desta tela são ilustrativos. Ainda não representam a grade oficial da faculdade.'}</p></div>}
        <section className="filter-panel" aria-label="Filtros de consulta">
          <div className="filter-heading"><div><Filter size={17} /><strong>Encontre uma sala ou aula</strong></div><span>Filtros</span></div>
          <div className="filter-grid">
            <label className="search-field"><Search size={17} /><input type="search" placeholder="Buscar por salas, professores ou disciplinas" value={search} onChange={(event) => setSearch(event.target.value)} /></label>
            <label className="select-field"><span>Tipo</span><select aria-label="Tipo de sala" value={type} onChange={(event) => setType(event.target.value)}><option value="">Todos</option><option>Sala de aula</option><option>Laboratório</option><option>Auditório</option></select><ChevronDown size={16} /></label>
            <label className="select-field"><span>Bloco</span><select aria-label="Bloco" value={block} onChange={(event) => setBlock(event.target.value)}><option value="">Todos</option>{[...new Set(rooms.map((room) => room.block))].sort().map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={16} /></label>
            <label className="select-field"><span>Status</span><select aria-label="Status" value={status} onChange={(event) => setStatus(event.target.value)}><option value="">Todos</option><option>Livres</option><option>Ocupada</option></select><ChevronDown size={16} /></label>
          </div>
          <div className="filter-bottom">
            <label className="time-choice"><span>Dia</span><select value={dayOfWeek} onChange={(event) => setDayOfWeek(Number(event.target.value))}>{days.map((day) => <option key={day.value} value={day.value}>{day.label}</option>)}</select></label>
            <label className="time-choice"><span>Horário</span><input type="text" inputMode="text" autoComplete="off" maxLength={5} placeholder="HH:mm" aria-label="Horário em horas e minutos" value={timeInput} onChange={(event) => { const value = event.target.value; setTimeInput(value); if (timeFormat.test(value)) setTime(value); }} onBlur={() => { if (!timeFormat.test(timeInput)) setTimeInput(time); }} /><Clock3 size={14} /></label>
            <span className="filter-hint"><Clock3 size={15} /> Os horários são consultados na programação do semestre.</span>
            <button className="text-button" type="button" onClick={() => { setSearch(''); setType(''); setBlock(''); setStatus(''); setSemester('2026/2'); setDayOfWeek(3); setTime('14:35'); setTimeInput('14:35'); }}>Limpar filtros</button>
          </div>
        </section>
        <section className="results-section">
          <div className="results-title"><div><h2>Salas neste horário</h2><p>{visibleRooms.length} {visibleRooms.length === 1 ? 'resultado' : 'resultados'}</p></div>{updated && <span className="published-label"><span className="status-dot status-dot-free" /> {sourceIsDemo ? 'Prévia de demonstração' : 'Grade publicada'}</span>}</div>
          {visibleRooms.length ? <div className="room-grid">{visibleRooms.map((room) => <RoomCard key={room.roomId} room={room} />)}</div> : <div className="empty-state"><Search size={24} /><h3>{rooms.length === 0 ? 'Nenhuma sala cadastrada ainda' : 'Nenhuma sala encontrada'}</h3><p>{rooms.length === 0 ? 'A administração ainda não publicou a grade deste semestre.' : 'Experimente limpar os filtros ou consultar outro horário.'}</p></div>}
        </section>
        <p className="panel-disclaimer"><Clock3 size={15} /> A ocupação mostrada é a prevista pela grade semestral publicada. Este painel não acompanha a localização de professores em tempo real.</p>
      </main>
    </div>
  );
}

function Metric({ label, value, icon, tone = '' }: { label: string; value: number; icon: React.ReactNode; tone?: string }) {
  return <article className={`metric-card ${tone ? `metric-${tone}` : ''}`}><div className="metric-label">{label}<span className="metric-icon">{icon}</span></div><strong>{String(value).padStart(2, '0')}</strong></article>;
}

function RoomCard({ room }: { room: RoomStatus }) {
  return <article className={`room-card ${room.occupied ? 'room-card-busy' : 'room-card-free'}`}>
    <div className="room-card-top"><div><span className="room-block">Bloco {room.block}</span><h3>{room.code}</h3></div><span className={`room-status ${room.occupied ? 'room-status-busy' : 'room-status-free'}`}><span className="status-dot" />{room.occupied ? 'Ocupada' : 'Livre'}</span></div>
    <div className="room-meta"><span>{room.roomType}</span>{room.capacity && <span>Capacidade {room.capacity}</span>}</div>
    {room.occupied ? <div className="room-schedule"><strong>{room.discipline || 'Aula programada'}</strong><span>{room.professor || 'Docente'}</span><small>{room.startsAt || '14:00'}–{room.endsAt || '15:40'}</small></div> : <div className="room-schedule room-free-copy">Sem aula prevista neste horário da grade.</div>}
  </article>;
}
