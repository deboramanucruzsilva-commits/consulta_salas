import { FormEvent, useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, ShieldCheck } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Brand } from '../components/SiteHeader';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth-context';

type Mode = 'login' | 'register';

export function AuthPage({ mode }: { mode: Mode }) {
  const isRegister = mode === 'register';
  const { user, refresh } = useAuth();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [occupation, setOccupation] = useState<'discente' | 'docente' | 'secretario'>('discente');
  const [registryNumber, setRegistryNumber] = useState('');

  useEffect(() => {
    if (user) navigate(user.role === 'admin' ? '/admin' : '/painel', { replace: true });
  }, [user, navigate]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    if (isRegister && password !== confirm) { setError('As senhas não coincidem.'); return; }
    setPending(true);
    try {
      if (isRegister) await api.register({ name, email, password, occupation, registryNumber });
      else await api.login({ email, password });
      await refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Não foi possível concluir. Tente novamente.');
    } finally { setPending(false); }
  };

  return (
    <main className="auth-page">
      <section className="auth-form-side">
        <Link className="back-link" to="/"><ArrowLeft size={17} /> Voltar ao início</Link>
        <div className="auth-form-wrap">
          <Brand />
          <div className="auth-heading">
            <div className="eyebrow"><span className="eyebrow-dot" /> UNIFEI · ITABIRA</div>
            <h1>{isRegister ? 'Cadastrar' : 'Entrar'}</h1>
            <p>{isRegister ? 'Crie seu acesso ao painel com e-mail e senha.' : 'Entre com seu e-mail e sua senha.'}</p>
          </div>
          <form className="profile-form" onSubmit={(event) => void submit(event)}>
            {isRegister && <label>Nome<input required value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" /></label>}
            <label>E-mail<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" /></label>
            <label>Senha<input required type="password" minLength={isRegister ? 8 : 1} value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={isRegister ? 'new-password' : 'current-password'} placeholder={isRegister ? 'Mínimo de 8 caracteres' : ''} /></label>
            {isRegister && (
              <>
                <label>Confirmar senha<input required type="password" minLength={8} value={confirm} onChange={(event) => setConfirm(event.target.value)} autoComplete="new-password" /></label>
                <label>Ocupação<select value={occupation} onChange={(event) => setOccupation(event.target.value as typeof occupation)}><option value="discente">Discente</option><option value="docente">Docente</option><option value="secretario">Secretário(a)</option></select></label>
                <label>Número de matrícula (RA)<input value={registryNumber} onChange={(event) => setRegistryNumber(event.target.value)} placeholder="Matrícula (opcional)" /></label>
              </>
            )}
            {error && <p className="form-error" role="alert">{error}</p>}
            <button type="submit" className="button button-primary button-large auth-submit" disabled={pending}>{pending ? 'Aguarde…' : isRegister ? 'Criar conta' : 'Entrar'} <ArrowRight size={18} /></button>
            <div className="auth-switch">{isRegister ? 'Já tem cadastro?' : 'Primeiro acesso?'} <Link to={isRegister ? '/login' : '/cadastro'}>{isRegister ? 'Entrar' : 'Cadastrar'}</Link></div>
            <div className="auth-trust"><ShieldCheck size={17} /> A ocupação escolhida não concede permissões administrativas. Esse acesso é dado separadamente pela administração.</div>
          </form>
        </div>
      </section>
      <aside className="auth-color-panel">
        <div className="auth-aside-card">
          <div className="auth-aside-emblem"><CalendarDaysIcon /></div>
          <div className="eyebrow">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <h2>Consulte a programação do semestre.</h2>
          <p>Salas e horários previstos conforme a grade publicada pela faculdade.</p>
          <div className="auth-aside-rule" />
          <span>Não é um serviço de localização em tempo real.</span>
        </div>
      </aside>
    </main>
  );
}

function CalendarDaysIcon() {
  return <span aria-hidden="true" className="calendar-emblem"><span /><span /><span /><span /><span /><span /><span /><span /></span>;
}
