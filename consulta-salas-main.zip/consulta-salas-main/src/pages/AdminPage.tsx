import { useEffect, useState } from 'react';
import { BookOpen, CalendarDays, LockKeyhole, Plus, Save, Trash2, Upload } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SiteHeader } from '../components/SiteHeader';
import { api, type Room, type Schedule, type SiteContent } from '../lib/api';
import { useAuth } from '../lib/auth-context';

export function AdminPage() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState<'schedules' | 'rooms' | 'import' | 'content'>('schedules');
  const [rooms, setRooms] = useState<Room[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [content, setContent] = useState<SiteContent[]>([]);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    try {
      const [roomResult, scheduleResult, contentResult] = await Promise.all([api.adminRooms(), api.adminSchedules(), api.content()]);
      setRooms(roomResult.rooms);
      setSchedules(scheduleResult.schedules);
      setContent(contentResult.content);
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Não foi possível carregar a área administrativa.'); }
  };

  useEffect(() => { if (user?.role === 'admin') void load(); }, [user]);

  if (loading) return <div className="auth-loading">Carregando sessão…</div>;
  if (!user) return <AccessGate title="Entrar para gerenciar" copy="A área administrativa exige uma sessão autenticada e uma permissão concedida pela administração." />;
  if (user.role !== 'admin') return <AccessGate title="Acesso restrito" copy="Sua conta não possui permissão administrativa. A edição das salas, da grade e das informações publicadas é exclusiva de administradores autorizados." />;

  return (
    <div className="application-page"><SiteHeader compact />
      <main className="admin-main">
        <div className="admin-title-row"><div><div className="eyebrow"><span className="eyebrow-dot" /> ÁREA ADMINISTRATIVA</div><h1>Gerenciar informações</h1><p>Atualize a grade semestral e o conteúdo disponibilizado aos usuários.</p></div><span className="admin-identity"><LockKeyhole size={15} /> Administrador</span></div>
        {notice && <div className="success-banner" role="status">{notice}</div>}{error && <div className="error-banner" role="alert">{error}</div>}
        <div className="admin-tabs" role="tablist" aria-label="Conteúdo administrativo"><button className={tab === 'schedules' ? 'admin-tab active' : 'admin-tab'} onClick={() => setTab('schedules')} role="tab"><CalendarDays size={17} /> Grade semestral</button><button className={tab === 'rooms' ? 'admin-tab active' : 'admin-tab'} onClick={() => setTab('rooms')} role="tab"><BookOpen size={17} /> Salas</button><button className={tab === 'import' ? 'admin-tab active' : 'admin-tab'} onClick={() => setTab('import')} role="tab"><Upload size={17} /> Importar planilha</button><button className={tab === 'content' ? 'admin-tab active' : 'admin-tab'} onClick={() => setTab('content')} role="tab"><Save size={17} /> Páginas informativas</button></div>
        {tab === 'schedules' && <SchedulesTab rooms={rooms} schedules={schedules} onChange={load} onNotice={setNotice} onError={setError} />}
        {tab === 'rooms' && <RoomsTab rooms={rooms} onChange={load} onNotice={setNotice} onError={setError} />}
        {tab === 'import' && <ImportTab onChange={load} onNotice={setNotice} onError={setError} />}
        {tab === 'content' && <ContentTab content={content} onNotice={setNotice} onError={setError} />}
        <div className="admin-security-note"><LockKeyhole size={16} /><span>As operações de edição são verificadas no servidor e requerem papel de administrador.</span></div>
      </main>
    </div>
  );
}

function AccessGate({ title, copy }: { title: string; copy: string }) {
  return <div className="application-page"><SiteHeader compact /><main className="access-gate"><div className="gate-icon"><LockKeyhole size={25} /></div><div className="eyebrow">PAINEL DE OCUPAÇÃO DE SALAS</div><h1>{title}</h1><p>{copy}</p><Link className="button button-primary" to="/login">Entrar</Link><Link className="text-link" to="/painel">Voltar para consulta</Link></main></div>;
}

function SchedulesTab({ rooms, schedules, onChange, onNotice, onError }: { rooms: Room[]; schedules: Schedule[]; onChange: () => Promise<void>; onNotice: (value: string) => void; onError: (value: string) => void }) {
  const [form, setForm] = useState({ roomId: '', semester: '2026/2', dayOfWeek: 3, startsAt: '14:00', endsAt: '15:40', professor: '', discipline: '' });
  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); onNotice(''); onError('');
    try {
      await api.createSchedule({ ...form, dayOfWeek: Number(form.dayOfWeek) });
      await onChange(); onNotice('Horário salvo e publicado na grade semestral.');
    } catch (caught) { onError(caught instanceof Error ? caught.message : 'Não foi possível salvar o horário.'); }
  };
  const remove = async (id: string) => {
    if (!window.confirm('Remover este horário da grade publicada?')) return;
    try { await api.deleteSchedule(id); await onChange(); onNotice('Horário removido.'); }
    catch (caught) { onError(caught instanceof Error ? caught.message : 'Não foi possível remover o horário.'); }
  };
  return <section className="admin-content"><div className="admin-content-heading"><div><h2>Grade semestral</h2><p>Associe disciplina, docente, sala e período.</p></div><span className="count-pill">{schedules.length} horários</span></div>
    <form className="admin-form-grid" onSubmit={(event) => void submit(event)}>
      <label>Sala<select required value={form.roomId} onChange={(event) => setForm({ ...form, roomId: event.target.value })}><option value="">Selecione uma sala</option>{rooms.map((room) => <option key={room.id} value={room.id}>{room.code} · Bloco {room.block}</option>)}</select></label>
      <label>Disciplina<input required value={form.discipline} onChange={(event) => setForm({ ...form, discipline: event.target.value })} placeholder="Nome da disciplina" /></label>
      <label>Professor(a)<input required value={form.professor} onChange={(event) => setForm({ ...form, professor: event.target.value })} placeholder="Nome do docente" /></label>
      <label>Semestre<select value={form.semester} onChange={(event) => setForm({ ...form, semester: event.target.value })}><option>2026/2</option><option>2026/1</option><option>2027/1</option></select></label>
      <label>Dia<select value={form.dayOfWeek} onChange={(event) => setForm({ ...form, dayOfWeek: Number(event.target.value) })}>{[['Segunda-feira',1],['Terça-feira',2],['Quarta-feira',3],['Quinta-feira',4],['Sexta-feira',5],['Sábado',6]].map(([day,value]) => <option value={value} key={value}>{day}</option>)}</select></label>
      <label>Início<input required type="time" value={form.startsAt} onChange={(event) => setForm({ ...form, startsAt: event.target.value })} /></label>
      <label>Término<input required type="time" value={form.endsAt} onChange={(event) => setForm({ ...form, endsAt: event.target.value })} /></label>
      <button className="button button-primary admin-submit" type="submit"><Plus size={16} /> Publicar horário</button>
    </form>
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Semestre</th><th>Dia / horário</th><th>Disciplina</th><th>Professor(a)</th><th>Sala</th><th></th></tr></thead><tbody>{schedules.map((item) => <tr key={item.id}><td>{item.semester}</td><td>{weekday(item.dayOfWeek)} · {item.startsAt}–{item.endsAt}</td><td>{item.discipline}</td><td>{item.professor}</td><td>{item.roomCode}</td><td><button className="icon-button danger-icon" aria-label={`Remover ${item.discipline}`} onClick={() => void remove(item.id)}><Trash2 size={16} /></button></td></tr>)}{schedules.length === 0 && <tr><td colSpan={6} className="table-empty">Nenhum horário cadastrado. Adicione a primeira aula acima.</td></tr>}</tbody></table></div>
  </section>;
}

function RoomsTab({ rooms, onChange, onNotice, onError }: { rooms: Room[]; onChange: () => Promise<void>; onNotice: (value: string) => void; onError: (value: string) => void }) {
  const [form, setForm] = useState({ code: '', block: '', roomType: 'Sala de aula', capacity: '' });
  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); onNotice(''); onError('');
    try { await api.createRoom({ ...form, capacity: form.capacity ? Number(form.capacity) : null }); await onChange(); setForm({ code: '', block: '', roomType: 'Sala de aula', capacity: '' }); onNotice('Sala cadastrada.'); }
    catch (caught) { onError(caught instanceof Error ? caught.message : 'Não foi possível cadastrar a sala.'); }
  };
  return <section className="admin-content"><div className="admin-content-heading"><div><h2>Salas cadastradas</h2><p>Cadastre cada espaço uma vez; depois, associe os horários à sala.</p></div><span className="count-pill">{rooms.length} salas</span></div><form className="admin-form-grid room-form-grid" onSubmit={(event) => void submit(event)}><label>Identificação da sala<input required value={form.code} onChange={(event) => setForm({ ...form, code: event.target.value })} placeholder="Ex.: E-201" /></label><label>Bloco<input required value={form.block} onChange={(event) => setForm({ ...form, block: event.target.value })} placeholder="Ex.: E" /></label><label>Tipo<select value={form.roomType} onChange={(event) => setForm({ ...form, roomType: event.target.value })}><option>Sala de aula</option><option>Laboratório</option><option>Auditório</option><option>Outro</option></select></label><label>Capacidade<input min="1" type="number" value={form.capacity} onChange={(event) => setForm({ ...form, capacity: event.target.value })} placeholder="Opcional" /></label><button className="button button-primary admin-submit" type="submit"><Plus size={16} /> Cadastrar sala</button></form><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Sala</th><th>Bloco</th><th>Tipo</th><th>Capacidade</th></tr></thead><tbody>{rooms.map((room) => <tr key={room.id}><td>{room.code}</td><td>{room.block}</td><td>{room.roomType}</td><td>{room.capacity ?? '—'}</td></tr>)}{rooms.length === 0 && <tr><td colSpan={4} className="table-empty">Nenhuma sala cadastrada.</td></tr>}</tbody></table></div></section>;
}

function ImportTab({ onChange, onNotice, onError }: { onChange: () => Promise<void>; onNotice: (value: string) => void; onError: (value: string) => void }) {
  const [semester, setSemester] = useState('2026/2');
  const [csv, setCsv] = useState('');
  const [details, setDetails] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const template = 'sala;bloco;tipo;capacidade;dia;inicio;fim;professor;disciplina\nE-201;E;Sala de aula;40;segunda;08:00;09:40;Nome do Professor;Nome da Disciplina\n';
  const download = () => {
    const url = URL.createObjectURL(new Blob(['\uFEFF' + template], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'modelo-grade.csv'; link.click(); URL.revokeObjectURL(url);
  };
  const pick = async (file: File | undefined) => {
    onNotice(''); onError(''); setDetails([]);
    if (!file) return;
    const text = await file.text();
    if (text.includes('\uFFFD')) { onError('O arquivo não está em UTF-8 (acentos ilegíveis). No Excel: Salvar como → "CSV UTF-8 (delimitado por vírgulas)".'); setCsv(''); return; }
    setCsv(text);
  };
  const send = async () => {
    onNotice(''); onError(''); setDetails([]); setBusy(true);
    try {
      const result = await api.importSchedules({ semester, csv });
      await onChange(); setDetails(result.details);
      onNotice(`Importação concluída: ${result.created} aulas criadas, ${result.skipped} ignoradas por conflito, ${result.rooms} salas envolvidas.`);
    } catch (caught) {
      onError(caught instanceof Error ? caught.message : 'Não foi possível importar.');
      setDetails((caught as { details?: string[] }).details ?? []);
    } finally { setBusy(false); }
  };
  return <section className="admin-content"><div className="admin-content-heading"><div><h2>Importar grade por planilha</h2><p>Carregue o semestre inteiro de uma vez. Salas novas são criadas automaticamente; aulas já existentes não são duplicadas.</p></div></div>
    <div className="admin-form-grid">
      <label>Semestre<input value={semester} onChange={(event) => setSemester(event.target.value)} placeholder="2026/2" pattern="\d{4}/[12]" /></label>
      <label>Arquivo CSV<input type="file" accept=".csv,text/csv,text/plain" onChange={(event) => void pick(event.target.files?.[0])} /></label>
      <button className="button button-small" type="button" onClick={download}>Baixar modelo</button>
      <button className="button button-primary admin-submit" type="button" disabled={!csv || busy} onClick={() => void send()}><Upload size={16} /> {busy ? 'Importando…' : 'Importar'}</button>
    </div>
    <p className="form-footnote">Colunas: sala, bloco, tipo, capacidade, dia (segunda a sábado), inicio, fim (HH:MM), professor, disciplina. Se houver erro em qualquer linha, nada é importado.</p>
    {csv && <p className="form-footnote">Arquivo lido: {csv.split(/\r?\n/).filter(Boolean).length - 1} linhas de dados.</p>}
    {details.length > 0 && <ul className="import-details">{details.map((line) => <li key={line}>{line}</li>)}</ul>}
  </section>;
}

function ContentTab({ content, onNotice, onError }: { content: SiteContent[]; onNotice: (value: string) => void; onError: (value: string) => void }) {
  const [values, setValues] = useState<Record<string, SiteContent>>({});
  useEffect(() => setValues(Object.fromEntries(content.map((item) => [item.slug, item]))), [content]);
  const save = async (slug: string) => {
    const value = values[slug]; if (!value) return;
    onNotice(''); onError('');
    try { await api.updateContent(slug, { title: value.title, body: value.body }); onNotice('Informação publicada para os usuários.'); }
    catch (caught) { onError(caught instanceof Error ? caught.message : 'Não foi possível salvar o conteúdo.'); }
  };
  return <section className="admin-content"><div className="admin-content-heading"><div><h2>Páginas informativas</h2><p>Edite o conteúdo público do início e das páginas do projeto.</p></div></div><div className="content-edit-list">{content.filter((item) => ['home','objetivo','como-funciona'].includes(item.slug)).map((item) => { const value = values[item.slug] ?? item; return <article className="content-edit-card" key={item.slug}><div className="content-edit-heading"><h3>{item.slug === 'home' ? 'Página inicial' : item.slug === 'objetivo' ? 'Objetivo' : 'Como funciona'}</h3><span className="slug-pill">{item.slug}</span></div><label>Título<input value={value.title} onChange={(event) => setValues({ ...values, [item.slug]: { ...value, title: event.target.value } })} /></label><label>Texto<textarea rows={4} value={value.body} onChange={(event) => setValues({ ...values, [item.slug]: { ...value, body: event.target.value } })} /></label><button className="button button-primary button-small" onClick={() => void save(item.slug)}><Save size={15} /> Publicar</button></article>; })}</div></section>;
}

function weekday(value: number) { return ['','Seg.','Ter.','Qua.','Qui.','Sex.','Sáb.','Dom.'][value] ?? '—'; }
