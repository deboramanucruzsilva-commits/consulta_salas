export type UserProfile = {
  name: string;
  email: string;
  role: 'user' | 'admin';
  occupation?: 'discente' | 'docente' | 'secretario';
  registryNumber?: string;
};

export type RoomStatus = {
  roomId: string;
  code: string;
  block: string;
  roomType: string;
  capacity: number | null;
  occupied: boolean;
  professor: string | null;
  discipline: string | null;
  dayOfWeek?: number;
  startsAt?: string;
  endsAt?: string;
};

export type Schedule = {
  id: string;
  roomId: string;
  roomCode: string;
  block: string;
  roomType: string;
  professor: string;
  discipline: string;
  dayOfWeek: number;
  startsAt: string;
  endsAt: string;
  semester: string;
  published: boolean;
};

export type Room = {
  id: string;
  code: string;
  block: string;
  roomType: string;
  capacity: number | null;
  published: boolean;
};

export type SiteContent = {
  slug: string;
  title: string;
  body: string;
};

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    credentials: 'include',
    headers: {
      ...(init?.body ? { 'Content-Type': 'application/json' } : {}),
      ...init?.headers,
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(typeof payload.error === 'string' ? payload.error : 'Não foi possível concluir a solicitação.');
  }
  return payload as T;
}

export const api = {
  me: () => request<{ user: UserProfile | null }>('/api/auth/me'),
  login: (payload: { email: string; password: string }) => request<{ user: UserProfile }>('/api/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  register: (payload: { name: string; email: string; password: string; occupation: string; registryNumber: string }) => request<{ user: UserProfile }>('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  logout: () => request<{ ok: true }>('/api/auth/logout', { method: 'POST' }),
  semesters: () => request<{ semesters: string[] }>('/api/semesters'),
  roomStatus: (params: { semester: string; dayOfWeek: number; time: string }) => {
    const query = new URLSearchParams({ ...params, dayOfWeek: String(params.dayOfWeek) });
    return request<{ rooms: RoomStatus[]; source: 'published' | 'empty' }>('/api/room-status?' + query);
  },
  content: () => request<{ content: SiteContent[] }>('/api/content'),
  adminRooms: () => request<{ rooms: Room[] }>('/api/admin/rooms'),
  adminSchedules: () => request<{ schedules: Schedule[] }>('/api/admin/schedules'),
  createRoom: (payload: Omit<Room, 'id' | 'published'>) => request<{ room: Room }>('/api/admin/rooms', {
    method: 'POST', body: JSON.stringify(payload),
  }),
  createSchedule: (payload: Omit<Schedule, 'id' | 'roomCode' | 'block' | 'roomType' | 'published'>) => request<{ schedule: Schedule }>('/api/admin/schedules', {
    method: 'POST', body: JSON.stringify(payload),
  }),
  deleteSchedule: (id: string) => request<{ ok: true }>(`/api/admin/schedules/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  updateContent: (slug: string, payload: Pick<SiteContent, 'title' | 'body'>) => request<{ content: SiteContent }>(`/api/admin/content/${encodeURIComponent(slug)}`, {
    method: 'PUT', body: JSON.stringify(payload),
  }),
  importSchedules: async (payload: { semester: string; csv: string }) => {
    const response = await fetch('/api/admin/import', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(typeof body.error === 'string' ? body.error : 'Não foi possível importar.') as Error & { details?: string[] }; error.details = body.details; throw error; }
    return body as { created: number; skipped: number; rooms: number; details: string[] };
  },
  updateProfile: (payload: { name: string; occupation: string; registryNumber: string }) => request<{ user: UserProfile }>('/api/profile', {
    method: 'PUT', body: JSON.stringify(payload),
  }),
};
