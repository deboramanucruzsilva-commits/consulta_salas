import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../lib/auth-context';

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link className={`brand ${compact ? 'brand-compact' : ''}`} to="/" aria-label="Painel de Ocupação de Salas — início">
      <img src="/77-107.webp" alt="" className="brand-mark" />
      <span className="brand-copy">
        <strong>PAINEL DE OCUPAÇÃO DE SALAS</strong>
        <small>UNIFEI - Itabira</small>
      </span>
    </Link>
  );
}

const links = [
  { to: '/', label: 'home', icon: '/77-116.svg', end: true },
  { to: '/objetivo', label: 'objetivo', icon: '/77-100.svg' },
  { to: '/como-funciona', label: 'como funciona', icon: '/77-112.svg' },
  { to: '/painel', label: 'consultar salas', icon: '/41-724.svg' },
];

export function SiteHeader({ compact = false, active = '' }: { compact?: boolean; active?: string }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const signOut = async () => {
    await logout();
    navigate('/');
    setMenuOpen(false);
  };

  return (
    <header className={`site-header ${compact ? 'site-header-compact' : ''}`}>
      <div className="header-top">
        <Brand compact={compact} />
        <div className="header-actions">
          {user ? (
            <>
              <span className="user-greeting">Olá, {user.name.split(' ')[0]}</span>
              {user.role === 'admin' && <Link className="button button-primary button-small" to="/admin">Gerenciar</Link>}
              <button className="icon-button logout-button" type="button" onClick={() => void signOut()} aria-label="Sair"><LogOut size={17} /></button>
            </>
          ) : (
            <>
              <Link className="button button-primary button-small" to="/login">Entrar</Link>
              <Link className="button button-primary button-small" to="/cadastro">Cadastrar</Link>
            </>
          )}
          <button className="icon-button mobile-menu-toggle" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'}>
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
      </div>
      <nav className={`main-nav ${menuOpen ? 'main-nav-open' : ''}`} aria-label="Navegação principal">
        {links.map((item) => (
          <NavLink
            to={item.to}
            key={item.to}
            end={item.end}
            onClick={() => setMenuOpen(false)}
            className={({ isActive }) => `nav-link ${isActive || active === item.label ? 'nav-link-active' : ''}`}
          >
            <img src={item.icon} alt="" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </header>
  );
}
