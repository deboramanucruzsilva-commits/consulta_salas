export default function FigmaSource() {
  return (
    <div data-layer="Frame 1" data-node-id="77-130" className="Frame1 w-[15831px] h-[9384px] relative bg-white overflow-hidden">
  <div data-layer="Desktop - 1" data-node-id="4-4" className="Desktop1 w-[1440px] h-[1024px] left-[2303px] top-[5901px] absolute bg-white overflow-hidden">
    <img data-layer="WhatsApp Image 2026-09-21 at 23.53.31 (1) 1" data-node-id="4-7" className="WhatsappImage20260921At23533111 w-[290px] h-[222px] left-[1013px] top-[135px] absolute" src="/4-7.webp" />
    <div data-layer="Ellipse 1" data-node-id="4-8" className="Ellipse1 w-[51px] h-[51px] left-[116px] top-[313px] absolute bg-[#d9d9d9] rounded-full" />
    <div data-layer="Ellipse 2" data-node-id="4-9" className="Ellipse2 w-[51px] h-[51px] left-[116px] top-[313px] absolute bg-[#084b91] rounded-full" />
    <div data-layer="Ellipse 3" data-node-id="4-12" className="Ellipse3 w-[51px] h-[51px] left-[116px] top-[415px] absolute bg-[#2882da] rounded-full" />
    <div data-layer="Ellipse 4" data-node-id="4-14" className="Ellipse4 w-[51px] h-[51px] left-[116px] top-[512px] absolute bg-[#87c1ff] rounded-full" />
    <div data-layer="Ellipse 5" data-node-id="4-19" className="Ellipse5 w-[51px] h-[51px] left-[116px] top-[614px] absolute bg-[#c4dffd] rounded-full" />
    <div data-layer="Ellipse 6" data-node-id="4-22" className="Ellipse6 w-[51px] h-[51px] left-[116px] top-[700px] absolute bg-[#f1f8ff] rounded-full" />
    <div data-layer="Ellipse 7" data-node-id="5-46" className="Ellipse7 w-[51px] h-[51px] left-[116px] top-[802px] absolute bg-[#1a2b3c] rounded-full" />
    <div data-layer="#084B91" data-node-id="4-16" className="084b91 left-[209px] top-[327px] absolute justify-start text-black text-xl font-normal font-['Inter']">#084B91</div>
    <div data-layer="Texto e tabelas : Inter Regular" data-node-id="5-38" className="TextoETabelasInterRegular left-[116px] top-[176px] absolute justify-start text-black text-xl font-normal font-['Inter']">Texto e tabelas : Inter Regular</div>
    <div data-layer="Nome/logo e títulos : Poppins SemiBold" data-node-id="5-39" className="NomeLogoETTulosPoppinsSemibold left-[116px] top-[122px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Nome/logo e títulos : Poppins SemiBold</div>
  </div>
  <div data-layer="HOME" data-node-id="4-5" className="Home w-[1440px] h-[1024px] left-[3743px] top-[5915px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Group 16" data-node-id="77-95" className="Group16 w-[1440px] h-[206px] left-0 top-0 absolute">
      <div data-layer="Rectangle 1" data-node-id="77-96" className="Rectangle1 w-[1440px] h-[206px] left-0 top-0 absolute bg-[#c4dffd]" />
      <div data-layer="Group 7" data-node-id="77-97" className="Group7 w-[109px] h-[30px] left-[468px] top-[146px] absolute">
        <div data-layer="objetivo" data-node-id="77-98" className="Objetivo left-[26px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">objetivo</div>
        <div data-layer="hugeicons:goal" data-node-id="77-99" className="HugeiconsGoal w-6 h-6 left-0 top-[3px] absolute overflow-hidden">
          <img data-layer="Group" data-node-id="77-100" className="Group w-4 h-[15px] left-[4px] top-[4px] absolute" src="/77-100.svg" />
        </div>
      </div>
      <div data-layer="Group 3" data-node-id="77-103" className="Group3 w-[570.75px] h-[75.14px] left-[36px] top-[32px] absolute">
        <div data-layer="Group 2" data-node-id="77-104" className="Group2 w-[455.15px] h-[67.95px] left-[115.59px] top-[5.78px] absolute">
          <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="77-105" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <div data-layer="UNIFEI - Itabira" data-node-id="77-106" className="UnifeiItabira left-[1.46px] top-[34.72px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
        </div>
        <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="77-107" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[96.81px] h-[75.14px] left-0 top-0 absolute" src="/77-107.webp" />
      </div>
      <div data-layer="como funciona" data-node-id="77-108" className="ComoFunciona left-[864px] top-[146px] absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
      <div data-layer="Group 8" data-node-id="77-109" className="Group8 w-[180px] h-[30px] left-[838px] top-[146px] absolute">
        <div data-layer="como funciona" data-node-id="77-110" className="ComoFunciona left-[26px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
        <div data-layer="basil:location-question-solid" data-node-id="77-111" className="BasilLocationQuestionSolid w-[26px] h-[26px] left-0 top-[2px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="77-112" className="Vector w-[17.89px] h-[21.85px] left-[4.06px] top-[1.63px] absolute" src="/77-112.svg" />
        </div>
      </div>
      <div data-layer="Group 5" data-node-id="77-113" className="Group5 w-[90px] h-[30px] left-[116px] top-[146px] absolute">
        <div data-layer="home" data-node-id="77-114" className="Home left-[30px] top-0 absolute justify-start text-[#2882da] text-xl font-semibold font-['Poppins']">home</div>
        <div data-layer="lucide/house" data-node-id="77-115" className="LucideHouse w-6 h-5 left-0 top-[5px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="77-116" className="Vector w-[18px] h-[15.83px] left-[3px] top-[1.67px] absolute" src="/77-116.svg" />
        </div>
      </div>
      <div data-layer="Group 17" data-node-id="77-117" className="Group17 w-[370px] h-[46px] left-[1025px] top-[50px] absolute">
        <div data-layer="Component 1" data-node-id="77-118" className="Component1 w-[140px] h-[46px] left-0 top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I77-118;5:60" className="Rectangle2 w-[140px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I77-118;5:61" className="Entrar left-[46px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Entrar</div>
        </div>
        <div data-layer="Component 2" data-node-id="77-119" className="Component2 w-[223px] h-[46px] left-[147px] top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I77-119;5:60" className="Rectangle2 w-[223px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I77-119;5:61" className="Entrar left-[73.27px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Cadastrar</div>
        </div>
      </div>
    </div>
  </div>
  <div data-layer="Painel - Admin" data-node-id="73-112" className="PainelAdmin w-[1440px] h-[1024px] left-[1226px] top-[3572px] absolute bg-white overflow-hidden">
    <div data-layer="Rectangle 7" data-node-id="73-113" className="Rectangle7 w-[1440px] h-[65px] left-0 top-0 absolute bg-[#c4dffd]" />
  </div>
  <div data-layer="Painel - Admin" data-node-id="23-591" className="PainelAdmin w-[1440px] h-[1024px] left-[3863px] top-[3442px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Group 15" data-node-id="23-592" className="Group15 w-[1440px] h-[65px] left-0 top-0 absolute">
      <div data-layer="Rectangle 1" data-node-id="23-593" className="Rectangle1 w-[1440px] h-[65px] left-0 top-0 absolute bg-[#c4dffd]" />
      <div data-layer="Group 3" data-node-id="23-594" className="Group3 w-[247px] h-[41px] left-[15px] top-[8px] absolute">
        <div data-layer="Group 2" data-node-id="23-595" className="Group2 w-[189px] h-[27px] left-[58px] top-[2px] absolute">
          <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="23-596" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xs font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <div data-layer="UNIFEI - Itabira" data-node-id="23-597" className="UnifeiItabira left-0 top-[15px] absolute justify-start text-[#084b91] text-[8px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
        </div>
        <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="23-598" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[54px] h-[41px] left-0 top-0 absolute" src="/23-598.webp" />
      </div>
      <div data-layer="Gerenciar" data-node-id="38-622" className="Gerenciar left-[1140px] top-[38px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Gerenciar</div>
      <div data-layer="Painel" data-node-id="23-600" className="Painel left-[142px] top-[38px] absolute justify-start text-[#2882da] text-[15px] font-semibold font-['Poppins']">Painel</div>
      <div data-layer="Professores" data-node-id="23-607" className="Professores left-[417px] top-[38px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Professores</div>
      <div data-layer="Group 19" data-node-id="39-624" className="Group19 w-[139px] h-[23px] left-[753px] top-[38px] absolute">
        <div data-layer="Como funciona" data-node-id="23-613" className="ComoFunciona left-[21px] top-0 absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Como funciona</div>
        <div data-layer="basil:location-question-solid" data-node-id="23-614" className="BasilLocationQuestionSolid w-[17px] h-[17px] left-0 top-[3px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="23-615" className="Vector w-[11.69px] h-[14.29px] left-[2.65px] top-[1.06px] absolute" src="/23-615.svg" />
        </div>
      </div>
      <div data-layer="Group 35" data-node-id="57-795" className="Group35 w-[97px] h-[45px] left-[1291px] top-[10px] absolute">
        <div data-layer="Usuário" data-node-id="57-788" className="UsuRio left-[52px] top-[15px] absolute justify-start text-[#084b91] text-xs font-semibold font-['Inter']">Usuário</div>
        <img data-layer="Vector" data-node-id="46-731" className="Vector w-[45px] h-[45px] left-0 top-0 absolute" src="/46-731.svg" />
      </div>
    </div>
    <div data-layer="Ocupação das salas" data-node-id="41-689" className="OcupaODasSalas left-[83px] top-[89px] absolute justify-start text-[#084b91] text-3xl font-semibold font-['Poppins']">Ocupação das salas</div>
    <div data-layer="Quarta-feira, 07/10 - 14:35" data-node-id="41-691" className="QuartaFeira07101435 left-[83px] top-[134px] absolute justify-start text-[#084b91] text-[15px] font-normal font-['Inter']">Quarta-feira, 07/10 - 14:35</div>
    <div data-layer="Group 23" data-node-id="41-714" className="Group23 w-[105px] h-[33px] left-[1252px] top-[95px] absolute rounded-[10px]">
      <div data-layer="Rectangle 4" data-node-id="41-715" className="Rectangle4 w-[105px] h-[33px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
      <div data-layer="Atualizar" data-node-id="41-716" className="Atualizar left-[16.99px] top-[6.47px] absolute text-center justify-center text-[#f1f8ff] text-[15px] font-semibold font-['Poppins']">Atualizar</div>
    </div>
    <div data-layer="Group 25" data-node-id="41-722" className="Group25 w-[210px] h-[33px] left-[1000px] top-[95px] absolute">
      <div data-layer="Group 24" data-node-id="41-718" className="Group24 w-[210px] h-[33px] left-0 top-0 absolute">
        <div data-layer="Rectangle 4" data-node-id="41-719" className="Rectangle4 w-[210px] h-[33px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Ver outros horários" data-node-id="41-720" className="VerOutrosHorRios left-[22px] top-[9px] absolute text-center justify-center text-[#084b91] text-[15px] font-semibold font-['Poppins']">Ver outros horários</div>
        <div data-layer="gg:select" data-node-id="41-723" className="GgSelect w-[17.74px] h-[17.74px] left-[180.33px] top-[8.43px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="41-724" className="Vector w-[8.36px] h-[11.90px] left-[4.43px] top-[2.96px] absolute" src="/41-724.svg" />
        </div>
      </div>
    </div>
    <div data-layer="Group 31" data-node-id="56-762" className="Group31 w-[574px] h-11 left-[64px] top-[295px] absolute rounded-[10px]">
      <div data-layer="Group 30" data-node-id="56-754" className="Group30 w-[574px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="56-756" className="Rectangle4 w-[574px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Buscar por salas, professores ou disciplinas" data-node-id="56-757" className="BuscarPorSalasProfessoresOuDisciplinas w-[393.50px] left-[34.75px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Buscar por salas, professores ou disciplinas</div>
      </div>
    </div>
    <div data-layer="Group 32" data-node-id="56-763" className="Group32 w-[210px] h-11 left-[674px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="56-764" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="56-765" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Tipo" data-node-id="56-766" className="Tipo left-[87px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Tipo</div>
      </div>
      <div data-layer="gg:select" data-node-id="56-768" className="GgSelect w-[21px] h-[21px] left-[171px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="56-769" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/56-769.svg" />
      </div>
    </div>
    <div data-layer="Group 33" data-node-id="57-772" className="Group33 w-[210px] h-11 left-[920px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="57-773" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="57-774" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Bloco" data-node-id="57-775" className="Bloco left-[79px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Bloco</div>
      </div>
      <div data-layer="gg:select" data-node-id="57-776" className="GgSelect w-[21px] h-[21px] left-[166px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="57-777" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/57-777.svg" />
      </div>
    </div>
    <div data-layer="Group 34" data-node-id="57-780" className="Group34 w-[210px] h-11 left-[1166px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="57-781" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="57-782" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Status" data-node-id="57-783" className="Status left-[77px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Status</div>
      </div>
      <div data-layer="gg:select" data-node-id="57-784" className="GgSelect w-[21px] h-[21px] left-[174px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="57-785" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/57-785.svg" />
      </div>
    </div>
    <div data-layer="Group 26" data-node-id="56-741" className="Group26 w-[420px] h-[87px] left-[64px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Rectangle 6" data-node-id="56-733" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
      <div data-layer="Total de salas" data-node-id="56-738" className="TotalDeSalas w-[110.75px] left-[140px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Total de salas</div>
      <div data-layer="27" data-node-id="56-739" className="w-[37.61px] left-[176.55px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">27</div>
    </div>
    <div data-layer="Group 28" data-node-id="56-747" className="Group28 w-[420px] h-[87px] left-[510px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Group 27" data-node-id="56-742" className="Group27 w-[420px] h-[87px] left-0 top-0 absolute rounded-[20px]">
        <div data-layer="Rectangle 6" data-node-id="56-743" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
        <div data-layer="Livres" data-node-id="56-744" className="Livres left-[169px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Livres</div>
        <div data-layer="09" data-node-id="56-745" className="left-[171px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">09</div>
      </div>
    </div>
    <div data-layer="Group 29" data-node-id="56-748" className="Group29 w-[420px] h-[87px] left-[956px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Group 27" data-node-id="56-749" className="Group27 w-[420px] h-[87px] left-0 top-0 absolute rounded-[20px]">
        <div data-layer="Rectangle 6" data-node-id="56-750" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
        <div data-layer="Ocupadas" data-node-id="56-751" className="Ocupadas left-[184px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Ocupadas</div>
        <div data-layer="18" data-node-id="56-752" className="left-[207px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">18</div>
      </div>
    </div>
    <div data-layer="gg:select" data-node-id="57-790" className="GgSelect w-[17.74px] h-[17.74px] left-[1392px] top-[25px] absolute overflow-hidden">
      <img data-layer="Vector" data-node-id="57-791" className="Vector w-[8.36px] h-[11.90px] left-[4.43px] top-[2.96px] absolute" src="/57-791.svg" />
    </div>
  </div>
  <div data-layer="Painel - Admin" data-node-id="73-33" className="PainelAdmin w-[1440px] h-[1024px] left-[5366px] top-[3442px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Group 15" data-node-id="73-34" className="Group15 w-[1440px] h-[65px] left-0 top-0 absolute">
      <div data-layer="Rectangle 1" data-node-id="73-35" className="Rectangle1 w-[1440px] h-[65px] left-0 top-0 absolute bg-[#c4dffd]" />
      <div data-layer="Group 3" data-node-id="73-36" className="Group3 w-[247px] h-[41px] left-[15px] top-[8px] absolute">
        <div data-layer="Group 2" data-node-id="73-37" className="Group2 w-[189px] h-[27px] left-[58px] top-[2px] absolute">
          <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="73-38" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xs font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <div data-layer="UNIFEI - Itabira" data-node-id="73-39" className="UnifeiItabira left-0 top-[15px] absolute justify-start text-[#084b91] text-[8px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
        </div>
        <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="73-40" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[54px] h-[41px] left-0 top-0 absolute" src="/73-40.webp" />
      </div>
      <div data-layer="Gerenciar" data-node-id="73-41" className="Gerenciar left-[1140px] top-[38px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Gerenciar</div>
      <div data-layer="Painel" data-node-id="73-42" className="Painel left-[142px] top-[38px] absolute justify-start text-[#2882da] text-[15px] font-semibold font-['Poppins']">Painel</div>
      <div data-layer="Professores" data-node-id="73-43" className="Professores left-[417px] top-[38px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Professores</div>
      <div data-layer="Group 19" data-node-id="73-44" className="Group19 w-[139px] h-[23px] left-[753px] top-[38px] absolute">
        <div data-layer="Como funciona" data-node-id="73-45" className="ComoFunciona left-[21px] top-0 absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">Como funciona</div>
        <div data-layer="basil:location-question-solid" data-node-id="73-46" className="BasilLocationQuestionSolid w-[17px] h-[17px] left-0 top-[3px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="73-47" className="Vector w-[11.69px] h-[14.29px] left-[2.65px] top-[1.06px] absolute" src="/73-47.svg" />
        </div>
      </div>
      <div data-layer="Group 35" data-node-id="73-48" className="Group35 w-[97px] h-[45px] left-[1291px] top-[10px] absolute">
        <div data-layer="Usuário" data-node-id="73-49" className="UsuRio left-[52px] top-[15px] absolute justify-start text-[#084b91] text-xs font-semibold font-['Inter']">Usuário</div>
        <img data-layer="Vector" data-node-id="73-50" className="Vector w-[45px] h-[45px] left-0 top-0 absolute" src="/73-50.svg" />
      </div>
    </div>
    <div data-layer="Ocupação das salas" data-node-id="73-51" className="OcupaODasSalas left-[83px] top-[89px] absolute justify-start text-[#084b91] text-3xl font-semibold font-['Poppins']">Ocupação das salas</div>
    <div data-layer="Quarta-feira, 07/10 - 14:35" data-node-id="73-52" className="QuartaFeira07101435 left-[83px] top-[134px] absolute justify-start text-[#084b91] text-[15px] font-normal font-['Inter']">Quarta-feira, 07/10 - 14:35</div>
    <div data-layer="Group 23" data-node-id="73-53" className="Group23 w-[105px] h-[33px] left-[1252px] top-[95px] absolute rounded-[10px]">
      <div data-layer="Rectangle 4" data-node-id="73-54" className="Rectangle4 w-[105px] h-[33px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
      <div data-layer="Atualizar" data-node-id="73-55" className="Atualizar left-[16.99px] top-[6.47px] absolute text-center justify-center text-[#f1f8ff] text-[15px] font-semibold font-['Poppins']">Atualizar</div>
    </div>
    <div data-layer="Group 25" data-node-id="73-56" className="Group25 w-[210px] h-[33px] left-[1000px] top-[95px] absolute">
      <div data-layer="Group 24" data-node-id="73-57" className="Group24 w-[210px] h-[33px] left-0 top-0 absolute">
        <div data-layer="Rectangle 4" data-node-id="73-58" className="Rectangle4 w-[210px] h-[33px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Ver outros horários" data-node-id="73-59" className="VerOutrosHorRios left-[22px] top-[9px] absolute text-center justify-center text-[#084b91] text-[15px] font-semibold font-['Poppins']">Ver outros horários</div>
        <div data-layer="gg:select" data-node-id="73-60" className="GgSelect w-[17.74px] h-[17.74px] left-[180.33px] top-[8.43px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="73-61" className="Vector w-[8.36px] h-[11.90px] left-[4.43px] top-[2.96px] absolute" src="/73-61.svg" />
        </div>
      </div>
    </div>
    <div data-layer="Group 31" data-node-id="73-62" className="Group31 w-[574px] h-11 left-[64px] top-[295px] absolute rounded-[10px]">
      <div data-layer="Group 30" data-node-id="73-63" className="Group30 w-[574px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="73-64" className="Rectangle4 w-[574px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Buscar por salas, professores ou disciplinas" data-node-id="73-65" className="BuscarPorSalasProfessoresOuDisciplinas w-[393.50px] left-[34.75px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Buscar por salas, professores ou disciplinas</div>
      </div>
    </div>
    <div data-layer="Group 32" data-node-id="73-66" className="Group32 w-[210px] h-11 left-[674px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="73-67" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="73-68" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Tipo" data-node-id="73-69" className="Tipo left-[87px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Tipo</div>
      </div>
      <div data-layer="gg:select" data-node-id="73-70" className="GgSelect w-[21px] h-[21px] left-[171px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="73-71" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/73-71.svg" />
      </div>
    </div>
    <div data-layer="Group 33" data-node-id="73-72" className="Group33 w-[210px] h-11 left-[920px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="73-73" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="73-74" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Bloco" data-node-id="73-75" className="Bloco left-[79px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Bloco</div>
      </div>
      <div data-layer="gg:select" data-node-id="73-76" className="GgSelect w-[21px] h-[21px] left-[166px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="73-77" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/73-77.svg" />
      </div>
    </div>
    <div data-layer="Group 34" data-node-id="73-78" className="Group34 w-[210px] h-11 left-[1166px] top-[295px] absolute">
      <div data-layer="Group 30" data-node-id="73-79" className="Group30 w-[210px] h-11 left-0 top-0 absolute rounded-[10px]">
        <div data-layer="Rectangle 4" data-node-id="73-80" className="Rectangle4 w-[210px] h-11 left-0 top-0 absolute bg-[#f1f8ff] rounded-[10px] border border-[#084b91]" />
        <div data-layer="Status" data-node-id="73-81" className="Status left-[77px] top-[12px] absolute justify-center text-[#084b91] text-[17px] font-normal font-['Inter']">Status</div>
      </div>
      <div data-layer="gg:select" data-node-id="73-82" className="GgSelect w-[21px] h-[21px] left-[174px] top-[12px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="73-83" className="Vector w-[13.59px] h-[17.29px] left-[1.24px] top-[1.24px] absolute" src="/73-83.svg" />
      </div>
    </div>
    <div data-layer="Group 26" data-node-id="73-84" className="Group26 w-[420px] h-[87px] left-[64px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Rectangle 6" data-node-id="73-85" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
      <div data-layer="Total de salas" data-node-id="73-86" className="TotalDeSalas w-[110.75px] left-[140px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Total de salas</div>
      <div data-layer="27" data-node-id="73-87" className="w-[37.61px] left-[176.55px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">27</div>
    </div>
    <div data-layer="Group 28" data-node-id="73-88" className="Group28 w-[420px] h-[87px] left-[510px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Group 27" data-node-id="73-89" className="Group27 w-[420px] h-[87px] left-0 top-0 absolute rounded-[20px]">
        <div data-layer="Rectangle 6" data-node-id="73-90" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
        <div data-layer="Livres" data-node-id="73-91" className="Livres left-[169px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Livres</div>
        <div data-layer="09" data-node-id="73-92" className="left-[171px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">09</div>
      </div>
    </div>
    <div data-layer="Group 29" data-node-id="73-93" className="Group29 w-[420px] h-[87px] left-[956px] top-[180px] absolute rounded-[20px]">
      <div data-layer="Group 27" data-node-id="73-94" className="Group27 w-[420px] h-[87px] left-0 top-0 absolute rounded-[20px]">
        <div data-layer="Rectangle 6" data-node-id="73-95" className="Rectangle6 w-[420px] h-[87px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px] border border-[#084b91]" />
        <div data-layer="Ocupadas" data-node-id="73-96" className="Ocupadas left-[184px] top-[8px] absolute justify-start text-[#084b91] text-[15px] font-medium font-['Poppins']">Ocupadas</div>
        <div data-layer="18" data-node-id="73-97" className="left-[207px] top-[31px] absolute justify-start text-[#084b91] text-[32px] font-semibold font-['Poppins']">18</div>
      </div>
    </div>
    <div data-layer="gg:select" data-node-id="73-98" className="GgSelect w-[17.74px] h-[17.74px] left-[1392px] top-[25px] absolute overflow-hidden">
      <img data-layer="Vector" data-node-id="73-99" className="Vector w-[8.36px] h-[11.90px] left-[4.43px] top-[2.96px] absolute" src="/73-99.svg" />
    </div>
    <div data-layer="Rectangle 6" data-node-id="73-100" className="Rectangle6 w-[286px] h-[391px] left-[1119px] top-[61px] absolute bg-[#f1f8ff] rounded-tl-[20px] rounded-bl-[20px] rounded-br-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)]" />
    <img data-layer="Group 35" data-node-id="73-101" className="Group35 w-[113.80px] h-[45px] left-[1291px] top-[10px] absolute" src="/73-101.svg" />
  </div>
  <div data-layer="Login" data-node-id="12-177" className="Login w-[1440px] h-[1024px] left-[3848px] top-[4668px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="12-178" className="Rectangle1 w-[720px] h-[1024px] left-[720px] top-[11px] absolute bg-[#c4dffd]" />
    <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="12-183" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145px] h-[111px] left-[150px] top-[83px] absolute" src="/12-183.webp" />
    <div data-layer="Component 1" data-node-id="12-188" className="Component1 w-56 h-[46px] left-[241px] top-[695px] absolute">
      <div data-layer="Rectangle 2" data-node-id="I12-188;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
      <div data-layer="Entrar" data-node-id="I12-188;5:61" className="Entrar left-[72.60px] top-[11px] absolute text-center justify-center text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
    </div>
    <div data-layer="Entrar" data-node-id="12-197" className="Entrar left-[156px] top-[224px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Entrar</div>
    <div data-layer="E-mail" data-node-id="12-232" className="EMail left-[156px] top-[443px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
    <div data-layer="Senha" data-node-id="12-246" className="Senha left-[156px] top-[550px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
    <div data-layer="Group 10" data-node-id="12-231" className="Group10 w-[386px] h-[100.80px] left-[160px] top-[322px] absolute">
      <div data-layer="Rectangle 3" data-node-id="12-218" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Continuar com Google" data-node-id="12-220" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
      <img data-layer="Vector" data-node-id="12-225" className="Vector w-3 h-3 left-[17.72px] top-[88.80px] absolute" src="/12-225.svg" />
    </div>
    <div data-layer="Group 11" data-node-id="12-238" className="Group11 w-[386px] h-[51px] left-[160px] top-[491px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="12-226" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Email" data-node-id="12-227" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
    </div>
    <div data-layer="Group 12" data-node-id="12-242" className="Group12 w-[386px] h-[51px] left-[156px] top-[596px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="12-243" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Senha" data-node-id="12-244" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
    </div>
    <div data-layer="ou" data-node-id="12-234" className="Ou left-[337px] top-[409px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
  </div>
  <div data-layer="Cadastro" data-node-id="12-248" className="Cadastro w-[1440px] h-[1024px] left-[5473px] top-[4664px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="12-249" className="Rectangle1 w-[720px] h-[1024px] left-[720px] top-0 absolute bg-[#c4dffd]" />
    <div data-layer="Group 36" data-node-id="57-865" className="Group36 w-[398px] h-[646px] left-[160px] top-[150px] absolute">
      <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="12-250" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145.02px] h-[110.99px] left-[2px] top-0 absolute" src="/12-250.webp" />
      <div data-layer="Cadastrar" data-node-id="12-252" className="Cadastrar left-[8px] top-[141px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Cadastrar</div>
      <div data-layer="E-mail" data-node-id="12-253" className="EMail left-0 top-[331px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
      <div data-layer="Senha" data-node-id="12-254" className="Senha left-0 top-[436px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
      <div data-layer="Group 10" data-node-id="12-255" className="Group10 w-[386px] h-[51px] left-[12px] top-[239px] absolute">
        <div data-layer="Rectangle 3" data-node-id="12-256" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Continuar com Google" data-node-id="12-257" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
        <img data-layer="Vector" data-node-id="12-258" className="Vector w-3 h-3 left-[19px] top-[19px] absolute" src="/12-258.svg" />
      </div>
      <div data-layer="Group 11" data-node-id="12-259" className="Group11 w-[386px] h-[51px] left-[8px] top-[376px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="12-260" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Email" data-node-id="12-261" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
      </div>
      <div data-layer="Nome de usuário" data-node-id="19-268" className="NomeDeUsuRio left-0 top-[549px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Nome de usuário</div>
      <div data-layer="Group 13" data-node-id="19-269" className="Group13 w-[386px] h-[51px] left-[8px] top-[595px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="19-270" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Usuário" data-node-id="19-271" className="UsuRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Usuário</div>
      </div>
      <div data-layer="Group 12" data-node-id="12-262" className="Group12 w-[386px] h-[51px] left-[8px] top-[483px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="12-263" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Senha" data-node-id="12-264" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
      </div>
      <div data-layer="ou" data-node-id="12-265" className="Ou left-[189px] top-[307px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
    </div>
    <div data-layer="Group 38" data-node-id="57-867" className="Group38 w-[393px] h-[459px] left-[883px] top-[323px] absolute">
      <div data-layer="Número de matrícula (RA)" data-node-id="19-273" className="NMeroDeMatrCulaRa left-0 top-[149px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Número de matrícula (RA)</div>
      <div data-layer="Group 14" data-node-id="19-274" className="Group14 w-[386px] h-[51px] left-[7px] top-[200px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="19-275" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
        <div data-layer="Matrícula" data-node-id="19-276" className="MatrCula left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Matrícula</div>
      </div>
      <div data-layer="Ocupação" data-node-id="23-307" className="OcupaO left-0 top-0 absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Ocupação</div>
      <div data-layer="Group 15" data-node-id="23-308" className="Group15 w-[386px] h-[51px] left-[7px] top-[51px] absolute">
        <div data-layer="Rectangle 4" data-node-id="23-309" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
        <div data-layer="Selecione ocupação" data-node-id="23-310" className="SelecioneOcupaO left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Selecione ocupação</div>
        <div data-layer="gg:select" data-node-id="23-352" className="GgSelect w-6 h-6 left-[341px] top-[13px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="23-353" className="Vector w-[11.31px] h-[16.10px] left-[6px] top-[4px] absolute" src="/23-353.svg" />
        </div>
      </div>
      <div data-layer="Component 2" data-node-id="23-367" className="Component2 w-56 h-[46px] left-[85px] top-[413px] absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-367;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-367;5:61" className="Entrar left-[73.60px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
      </div>
    </div>
  </div>
  <div data-layer="Cadastro 1" data-node-id="23-313" className="Cadastro1 w-[1440px] h-[1024px] left-[7013px] top-[4664px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="23-314" className="Rectangle1 w-[720px] h-[1024px] left-[720px] top-[-2px] absolute bg-[#c4dffd]" />
    <div data-layer="Group 37" data-node-id="57-866" className="Group37 w-[398px] h-[646px] left-[160px] top-[150px] absolute">
      <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="23-315" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145.02px] h-[110.99px] left-[2px] top-0 absolute" src="/23-315.webp" />
      <div data-layer="Cadastrar" data-node-id="23-317" className="Cadastrar left-[8px] top-[141px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Cadastrar</div>
      <div data-layer="E-mail" data-node-id="23-318" className="EMail left-0 top-[331px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
      <div data-layer="Senha" data-node-id="23-319" className="Senha left-0 top-[436px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
      <div data-layer="Group 10" data-node-id="23-320" className="Group10 w-[386px] h-[51px] left-[12px] top-[239px] absolute">
        <div data-layer="Rectangle 3" data-node-id="23-321" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Continuar com Google" data-node-id="23-322" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
        <img data-layer="Vector" data-node-id="23-323" className="Vector w-3 h-3 left-[19px] top-[19px] absolute" src="/23-323.svg" />
      </div>
      <div data-layer="Group 11" data-node-id="23-324" className="Group11 w-[386px] h-[51px] left-[8px] top-[376px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-325" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Email" data-node-id="23-326" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
      </div>
      <div data-layer="Nome de usuário" data-node-id="23-327" className="NomeDeUsuRio left-0 top-[549px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Nome de usuário</div>
      <div data-layer="Group 13" data-node-id="23-328" className="Group13 w-[386px] h-[51px] left-[8px] top-[595px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-329" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Usuário" data-node-id="23-330" className="UsuRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Usuário</div>
      </div>
      <div data-layer="Group 12" data-node-id="23-339" className="Group12 w-[386px] h-[51px] left-[8px] top-[483px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-340" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Senha" data-node-id="23-341" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
      </div>
      <div data-layer="ou" data-node-id="23-342" className="Ou left-[189px] top-[307px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
    </div>
    <div data-layer="Group 45" data-node-id="57-875" className="Group45 w-[393px] h-[459px] left-[883px] top-[323px] absolute">
      <div data-layer="Group 44" data-node-id="57-874" className="Group44 w-[393px] h-[260px] left-0 top-0 absolute">
        <div data-layer="Número de matrícula (RA)" data-node-id="23-331" className="NMeroDeMatrCulaRa left-0 top-[149px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Número de matrícula (RA)</div>
        <div data-layer="Group 14" data-node-id="23-332" className="Group14 w-[386px] h-[51px] left-[7px] top-[200px] absolute rounded-[20px]">
          <div data-layer="Rectangle 4" data-node-id="23-333" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
          <div data-layer="Email" data-node-id="23-334" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
        </div>
        <div data-layer="Ocupação" data-node-id="23-335" className="OcupaO left-0 top-0 absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Ocupação</div>
        <div data-layer="Group 43" data-node-id="57-873" className="Group43 w-[386px] h-[209px] left-[7px] top-[51px] absolute">
          <div data-layer="Group 42" data-node-id="57-872" className="Group42 w-[386px] h-[209px] left-0 top-0 absolute">
            <div data-layer="Group 15" data-node-id="23-336" className="Group15 w-[386px] h-[51px] left-0 top-0 absolute">
              <div data-layer="Rectangle 4" data-node-id="23-337" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-tl-[20px] rounded-tr-[20px] rounded-bl-sm rounded-br-sm" />
              <div data-layer="Selecione a ocupação" data-node-id="23-338" className="SelecioneAOcupaO left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Selecione a ocupação</div>
              <div data-layer="gg:select" data-node-id="23-360" className="GgSelect w-6 h-6 left-[341px] top-[13px] absolute overflow-hidden">
                <img data-layer="Vector" data-node-id="23-361" className="Vector w-[11.31px] h-[16.10px] left-[6px] top-[4px] absolute" src="/23-361.svg" />
              </div>
            </div>
            <div data-layer="Group 16" data-node-id="23-355" className="Group16 w-[386px] h-[162px] left-0 top-[47px] absolute shadow-[0px_1px_3px_1px_rgba(0,0,0,0.15)] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.30)]">
              <div data-layer="Rectangle 4" data-node-id="23-356" className="Rectangle4 w-[386px] h-[162px] left-0 top-0 absolute bg-[#f1f8ff] rounded-tl-[20px] rounded-tr-[20px] rounded-bl-sm rounded-br-sm" />
            </div>
            <div data-layer="Group 18" data-node-id="23-364" className="Group18 w-[156px] h-[123px] left-[28px] top-[63px] absolute">
              <div data-layer="Discente" data-node-id="23-347" className="Discente left-0 top-[35px] absolute justify-start text-[#5d6b78] text-[15px] font-normal font-['Inter']">Discente</div>
              <div data-layer="Selecione a ocupação" data-node-id="23-365" className="SelecioneAOcupaO left-0 top-0 absolute justify-start text-[#5d6b78] text-[15px] font-normal font-['Inter']">Selecione a ocupação</div>
              <div data-layer="Docente" data-node-id="23-348" className="Docente left-0 top-[70px] absolute justify-start text-[#5d6b78] text-[15px] font-normal font-['Inter']">Docente</div>
              <div data-layer="Secretário(a)" data-node-id="23-350" className="SecretRioA left-0 top-[105px] absolute justify-start text-[#5d6b78] text-[15px] font-normal font-['Inter']">Secretário(a)</div>
            </div>
          </div>
        </div>
      </div>
      <div data-layer="Component 2" data-node-id="23-371" className="Component2 w-56 h-[46px] left-[85px] top-[413px] absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-371;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-371;5:61" className="Entrar left-[73.60px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
      </div>
    </div>
  </div>
  <div data-layer="Cadastro 2" data-node-id="23-375" className="Cadastro2 w-[1440px] h-[1024px] left-[8553px] top-[4664px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="23-376" className="Rectangle1 w-[720px] h-[1024px] left-[720px] top-[-3px] absolute bg-[#c4dffd]" />
    <div data-layer="Group 41" data-node-id="57-870" className="Group41 w-[398px] h-[646px] left-[160px] top-[150px] absolute">
      <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="23-377" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145.02px] h-[110.99px] left-[2px] top-0 absolute" src="/23-377.webp" />
      <div data-layer="Cadastrar" data-node-id="23-379" className="Cadastrar left-[8px] top-[141px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Cadastrar</div>
      <div data-layer="E-mail" data-node-id="23-380" className="EMail left-0 top-[331px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
      <div data-layer="Senha" data-node-id="23-381" className="Senha left-0 top-[436px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
      <div data-layer="Group 40" data-node-id="57-869" className="Group40 w-[386px] h-[115.72px] left-[12px] top-[239px] absolute">
        <div data-layer="Group 10" data-node-id="23-382" className="Group10 w-[386px] h-[115.72px] left-0 top-0 absolute">
          <div data-layer="Rectangle 3" data-node-id="23-383" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
          <div data-layer="Continuar com Google" data-node-id="23-384" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
          <img data-layer="Vector" data-node-id="23-385" className="Vector w-3 h-3 left-[12.32px] top-[103.72px] absolute" src="/23-385.svg" />
        </div>
      </div>
      <div data-layer="Group 11" data-node-id="23-386" className="Group11 w-[386px] h-[51px] left-[8px] top-[376px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-387" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Email" data-node-id="23-388" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
      </div>
      <div data-layer="Nome de usuário" data-node-id="23-389" className="NomeDeUsuRio left-0 top-[549px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Nome de usuário</div>
      <div data-layer="Group 13" data-node-id="23-390" className="Group13 w-[386px] h-[51px] left-[8px] top-[595px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-391" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Usuário" data-node-id="23-392" className="UsuRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Usuário</div>
      </div>
      <div data-layer="Group 12" data-node-id="23-405" className="Group12 w-[386px] h-[51px] left-[8px] top-[483px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-406" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Senha" data-node-id="23-407" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
      </div>
      <div data-layer="ou" data-node-id="23-408" className="Ou left-[189px] top-[307px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
    </div>
    <div data-layer="Group 47" data-node-id="57-877" className="Group47 w-[393px] h-[459px] left-[883px] top-[323px] absolute">
      <div data-layer="Group 46" data-node-id="57-876" className="Group46 w-[393px] h-[251px] left-0 top-0 absolute">
        <div data-layer="Número de matrícula (RA)" data-node-id="23-393" className="NMeroDeMatrCulaRa left-0 top-[149px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Número de matrícula (RA)</div>
        <div data-layer="Group 14" data-node-id="23-394" className="Group14 w-[386px] h-[51px] left-[7px] top-[200px] absolute rounded-[20px]">
          <div data-layer="Rectangle 4" data-node-id="23-395" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
          <div data-layer="Matrícula" data-node-id="23-396" className="MatrCula left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Matrícula</div>
        </div>
        <div data-layer="Ocupação" data-node-id="23-397" className="OcupaO left-0 top-0 absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Ocupação</div>
        <div data-layer="Group 15" data-node-id="23-398" className="Group15 w-[386px] h-[51px] left-[7px] top-[51px] absolute">
          <div data-layer="Rectangle 4" data-node-id="23-399" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
          <div data-layer="Discente" data-node-id="23-400" className="Discente left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Discente</div>
          <div data-layer="gg:select" data-node-id="23-401" className="GgSelect w-6 h-6 left-[341px] top-[13px] absolute overflow-hidden">
            <img data-layer="Vector" data-node-id="23-402" className="Vector w-[11.31px] h-[16.10px] left-[6px] top-[4px] absolute" src="/23-402.svg" />
          </div>
        </div>
      </div>
      <div data-layer="Component 2" data-node-id="23-414" className="Component2 w-56 h-[46px] left-[85px] top-[413px] absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-414;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-414;5:61" className="Entrar left-[73.60px] top-0 absolute justify-start text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
      </div>
    </div>
  </div>
  <div data-layer="Cadastro 3" data-node-id="23-510" className="Cadastro3 w-[1440px] h-[1024px] left-[10093px] top-[4664px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="23-511" className="Rectangle1 w-[720px] h-[1024px] left-[715px] top-0 absolute bg-[#c4dffd]" />
    <div data-layer="Group 48" data-node-id="57-878" className="Group48 w-[398px] h-[646px] left-[160px] top-[150px] absolute">
      <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="23-512" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145.02px] h-[110.99px] left-[2px] top-0 absolute" src="/23-512.webp" />
      <div data-layer="Cadastrar" data-node-id="23-514" className="Cadastrar left-[8px] top-[141px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Cadastrar</div>
      <div data-layer="E-mail" data-node-id="23-515" className="EMail left-0 top-[331px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
      <div data-layer="Senha" data-node-id="23-516" className="Senha left-0 top-[436px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
      <div data-layer="Group 10" data-node-id="23-517" className="Group10 w-[386px] h-[51px] left-[12px] top-[239px] absolute">
        <div data-layer="Rectangle 3" data-node-id="23-518" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Continuar com Google" data-node-id="23-519" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
        <img data-layer="Vector" data-node-id="23-520" className="Vector w-3 h-3 left-[25px] top-[19px] absolute" src="/23-520.svg" />
      </div>
      <div data-layer="Group 11" data-node-id="23-521" className="Group11 w-[386px] h-[51px] left-[8px] top-[376px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-522" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Email" data-node-id="23-523" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
      </div>
      <div data-layer="Nome de usuário" data-node-id="23-524" className="NomeDeUsuRio left-0 top-[549px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Nome de usuário</div>
      <div data-layer="Group 13" data-node-id="23-525" className="Group13 w-[386px] h-[51px] left-[8px] top-[595px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-526" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Usuário" data-node-id="23-527" className="UsuRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Usuário</div>
      </div>
      <div data-layer="Group 12" data-node-id="23-538" className="Group12 w-[386px] h-[51px] left-[8px] top-[483px] absolute rounded-[20px]">
        <div data-layer="Rectangle 4" data-node-id="23-539" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Senha" data-node-id="23-540" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
      </div>
      <div data-layer="ou" data-node-id="23-541" className="Ou left-[189px] top-[307px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
    </div>
    <div data-layer="Group 51" data-node-id="57-881" className="Group51 w-[393px] h-[459px] left-[883px] top-[323px] absolute">
      <div data-layer="Group 49" data-node-id="57-879" className="Group49 w-[393px] h-[251px] left-0 top-0 absolute">
        <div data-layer="Número de matrícula (RA)" data-node-id="23-528" className="NMeroDeMatrCulaRa left-0 top-[149px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Número de matrícula (RA)</div>
        <div data-layer="Group 14" data-node-id="23-529" className="Group14 w-[386px] h-[51px] left-[7px] top-[200px] absolute rounded-[20px]">
          <div data-layer="Rectangle 4" data-node-id="23-530" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
          <div data-layer="Matrícula" data-node-id="23-531" className="MatrCula left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Matrícula</div>
        </div>
        <div data-layer="Ocupação" data-node-id="23-532" className="OcupaO left-0 top-0 absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Ocupação</div>
        <div data-layer="Group 15" data-node-id="23-533" className="Group15 w-[386px] h-[51px] left-[7px] top-[51px] absolute">
          <div data-layer="Rectangle 4" data-node-id="23-534" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
          <div data-layer="Docente" data-node-id="23-535" className="Docente left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Docente</div>
          <div data-layer="gg:select" data-node-id="23-536" className="GgSelect w-6 h-6 left-[341px] top-[13px] absolute overflow-hidden">
            <img data-layer="Vector" data-node-id="23-537" className="Vector w-[11.31px] h-[16.10px] left-[6px] top-[4px] absolute" src="/23-537.svg" />
          </div>
        </div>
      </div>
      <div data-layer="Component 2" data-node-id="23-542" className="Component2 w-56 h-[46px] left-[85px] top-[413px] absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-542;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-542;5:61" className="Entrar left-[73.60px] top-0 absolute justify-start text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
      </div>
    </div>
  </div>
  <div data-layer="Cadastro 4" data-node-id="23-548" className="Cadastro4 w-[1500px] h-[850px] left-[11633px] top-[4664px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="23-549" className="Rectangle1 w-[750px] h-[850px] left-[750px] top-0 absolute bg-[#c4dffd]" />
    <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="23-550" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[145px] h-[111px] left-[141px] top-[97px] absolute" src="/23-550.webp" />
    <div data-layer="Component 1" data-node-id="23-551" className="Component1 w-56 h-[46px] left-[1001px] top-[910px] absolute">
      <div data-layer="Rectangle 2" data-node-id="I23-551;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
      <div data-layer="Entrar" data-node-id="I23-551;5:61" className="Entrar left-[73.60px] top-0 absolute justify-start text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
    </div>
    <div data-layer="Cadastrar" data-node-id="23-552" className="Cadastrar left-[147px] top-[238px] absolute justify-start text-[#084b91] text-[40px] font-semibold font-['Poppins']">Cadastrar</div>
    <div data-layer="E-mail" data-node-id="23-553" className="EMail left-[139px] top-[428px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">E-mail</div>
    <div data-layer="Senha" data-node-id="23-554" className="Senha left-[139px] top-[533px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Senha</div>
    <div data-layer="Group 50" data-node-id="57-880" className="Group50 w-[386px] h-[51px] left-[151px] top-[336px] absolute">
      <div data-layer="Group 10" data-node-id="23-555" className="Group10 w-[386px] h-[51px] left-0 top-0 absolute">
        <div data-layer="Rectangle 3" data-node-id="23-556" className="Rectangle3 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
        <div data-layer="Continuar com Google" data-node-id="23-557" className="ContinuarComGoogle left-[87px] top-[12px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">Continuar com Google</div>
        <img data-layer="Vector" data-node-id="23-558" className="Vector w-[12.50px] h-2.5 left-[20px] top-[20px] absolute" src="/23-558.svg" />
      </div>
    </div>
    <div data-layer="Group 11" data-node-id="23-559" className="Group11 w-[386px] h-[51px] left-[147px] top-[473px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="23-560" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Email" data-node-id="23-561" className="Email left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Email</div>
    </div>
    <div data-layer="Nome de usuário" data-node-id="23-562" className="NomeDeUsuRio left-[139px] top-[646px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Nome de usuário</div>
    <div data-layer="Group 13" data-node-id="23-563" className="Group13 w-[386px] h-[51px] left-[147px] top-[692px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="23-564" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Usuário" data-node-id="23-565" className="UsuRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Usuário</div>
    </div>
    <div data-layer="Número de matrícula (RA)" data-node-id="23-566" className="NMeroDeMatrCulaRa left-[862px] top-[285px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Número de matrícula (RA)</div>
    <div data-layer="Group 14" data-node-id="23-567" className="Group14 w-[386px] h-[51px] left-[869px] top-[336px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="23-568" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
      <div data-layer="Matrícula" data-node-id="23-569" className="MatrCula left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Matrícula</div>
    </div>
    <div data-layer="Ocupação" data-node-id="23-570" className="OcupaO left-[862px] top-[136px] absolute justify-start text-[#084b91] text-[25px] font-semibold font-['Poppins']">Ocupação</div>
    <div data-layer="Group 15" data-node-id="23-571" className="Group15 w-[386px] h-[51px] left-[869px] top-[187px] absolute">
      <div data-layer="Rectangle 4" data-node-id="23-572" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#f1f8ff] rounded-[20px]" />
      <div data-layer="Secretário" data-node-id="23-573" className="SecretRio left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Secretário</div>
      <div data-layer="gg:select" data-node-id="23-574" className="GgSelect w-6 h-6 left-[341px] top-[13px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="23-575" className="Vector w-[11.31px] h-[16.10px] left-[6px] top-[4px] absolute" src="/23-575.svg" />
      </div>
    </div>
    <div data-layer="Group 12" data-node-id="23-576" className="Group12 w-[386px] h-[51px] left-[147px] top-[580px] absolute rounded-[20px]">
      <div data-layer="Rectangle 4" data-node-id="23-577" className="Rectangle4 w-[386px] h-[51px] left-0 top-0 absolute bg-[#c4dffd] rounded-[20px]" />
      <div data-layer="Senha" data-node-id="23-578" className="Senha left-[28px] top-[13px] absolute justify-start text-[#1a2b3c]/70 text-xl font-normal font-['Inter']">Senha</div>
    </div>
    <div data-layer="ou" data-node-id="23-579" className="Ou left-[328px] top-[404px] absolute justify-start text-[#1a2b3c] text-xl font-normal font-['Inter']">ou</div>
    <div data-layer="Component 2" data-node-id="23-580" className="Component2 w-56 h-[46px] left-[1001px] top-[559px] absolute">
      <div data-layer="Rectangle 2" data-node-id="I23-580;5:60" className="Rectangle2 w-56 h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
      <div data-layer="Entrar" data-node-id="I23-580;5:61" className="Entrar left-[73.60px] top-0 absolute justify-start text-white text-[15px] font-bold font-['Poppins']">Continuar</div>
    </div>
  </div>
  <div data-layer="OBJETIVO" data-node-id="9-5" className="Objetivo w-[1440px] h-[1024px] left-[5316px] top-[5915px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Group 16" data-node-id="23-281" className="Group16 w-[1440px] h-[206px] left-0 top-0 absolute">
      <div data-layer="Rectangle 1" data-node-id="9-6" className="Rectangle1 w-[1440px] h-[206px] left-0 top-0 absolute bg-[#c4dffd]" />
      <div data-layer="Group 7" data-node-id="9-66" className="Group7 w-[109px] h-[30px] left-[468px] top-[146px] absolute">
        <div data-layer="objetivo" data-node-id="9-67" className="Objetivo left-[26px] top-0 absolute justify-start text-[#2882da] text-xl font-semibold font-['Poppins']">objetivo</div>
        <div data-layer="hugeicons:goal" data-node-id="9-68" className="HugeiconsGoal w-6 h-6 left-0 top-[3px] absolute overflow-hidden">
          <img data-layer="Group" data-node-id="9-69" className="Group w-4 h-[15px] left-[4px] top-[4px] absolute" src="/9-69.svg" />
        </div>
      </div>
      <div data-layer="Group 3" data-node-id="9-7" className="Group3 w-[570.75px] h-[75.14px] left-[36px] top-[32px] absolute">
        <div data-layer="Group 2" data-node-id="9-8" className="Group2 w-[455.15px] h-[67.95px] left-[115.59px] top-[5.78px] absolute">
          <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="9-9" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <div data-layer="UNIFEI - Itabira" data-node-id="9-10" className="UnifeiItabira left-[1.46px] top-[34.72px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
        </div>
        <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="9-11" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[96.81px] h-[75.14px] left-0 top-0 absolute" src="/9-11.webp" />
      </div>
      <div data-layer="como funciona" data-node-id="9-14" className="ComoFunciona left-[864px] top-[146px] absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
      <div data-layer="Group 8" data-node-id="9-80" className="Group8 w-[180px] h-[30px] left-[838px] top-[146px] absolute">
        <div data-layer="como funciona" data-node-id="9-81" className="ComoFunciona left-[26px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
        <div data-layer="basil:location-question-solid" data-node-id="9-82" className="BasilLocationQuestionSolid w-[26px] h-[26px] left-0 top-[2px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="9-83" className="Vector w-[17.89px] h-[21.85px] left-[4.06px] top-[1.63px] absolute" src="/9-83.svg" />
        </div>
      </div>
      <div data-layer="Group 5" data-node-id="9-50" className="Group5 w-[90px] h-[30px] left-[116px] top-[146px] absolute">
        <div data-layer="home" data-node-id="9-51" className="Home left-[30px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">home</div>
        <div data-layer="lucide/house" data-node-id="9-52" className="LucideHouse w-6 h-5 left-0 top-[5px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="9-53" className="Vector w-[18px] h-[15.83px] left-[3px] top-[1.67px] absolute" src="/9-53.svg" />
        </div>
      </div>
      <div data-layer="Group 17" data-node-id="23-283" className="Group17 w-[370px] h-[46px] left-[1025px] top-[50px] absolute">
        <div data-layer="Component 1" data-node-id="23-284" className="Component1 w-[140px] h-[46px] left-0 top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I23-284;5:60" className="Rectangle2 w-[140px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I23-284;5:61" className="Entrar left-[46px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Entrar</div>
        </div>
        <div data-layer="Component 2" data-node-id="23-285" className="Component2 w-[223px] h-[46px] left-[147px] top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I23-285;5:60" className="Rectangle2 w-[223px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I23-285;5:61" className="Entrar left-[73.27px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Cadastrar</div>
        </div>
      </div>
    </div>
    <div data-layer="Group 17" data-node-id="77-61" className="Group17 w-[1440px] h-[206px] left-0 top-0 absolute">
      <div data-layer="Rectangle 1" data-node-id="77-62" className="Rectangle1 w-[1440px] h-[206px] left-0 top-0 absolute bg-[#c4dffd]" />
      <div data-layer="Group 7" data-node-id="77-63" className="Group7 w-[109px] h-[30px] left-[468px] top-[146px] absolute">
        <div data-layer="objetivo" data-node-id="77-64" className="Objetivo left-[26px] top-0 absolute justify-start text-[#2882da] text-xl font-semibold font-['Poppins']">objetivo</div>
        <div data-layer="hugeicons:goal" data-node-id="77-65" className="HugeiconsGoal w-6 h-6 left-0 top-[3px] absolute overflow-hidden">
          <img data-layer="Group" data-node-id="77-66" className="Group w-4 h-[15px] left-[4px] top-[4px] absolute" src="/77-66.svg" />
        </div>
      </div>
      <div data-layer="Group 3" data-node-id="77-69" className="Group3 w-[570.75px] h-[75.14px] left-[36px] top-[32px] absolute">
        <div data-layer="Group 2" data-node-id="77-70" className="Group2 w-[455.15px] h-[67.95px] left-[115.59px] top-[5.78px] absolute">
          <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="77-71" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
          <div data-layer="UNIFEI - Itabira" data-node-id="77-72" className="UnifeiItabira left-[1.46px] top-[34.72px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
        </div>
        <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="77-73" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[96.81px] h-[75.14px] left-0 top-0 absolute" src="/77-73.webp" />
      </div>
      <div data-layer="como funciona" data-node-id="77-74" className="ComoFunciona left-[864px] top-[146px] absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
      <div data-layer="Group 8" data-node-id="77-75" className="Group8 w-[180px] h-[30px] left-[838px] top-[146px] absolute">
        <div data-layer="como funciona" data-node-id="77-76" className="ComoFunciona left-[26px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
        <div data-layer="basil:location-question-solid" data-node-id="77-77" className="BasilLocationQuestionSolid w-[26px] h-[26px] left-0 top-[2px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="77-78" className="Vector w-[17.89px] h-[21.85px] left-[4.06px] top-[1.63px] absolute" src="/77-78.svg" />
        </div>
      </div>
      <div data-layer="Group 5" data-node-id="77-79" className="Group5 w-[90px] h-[30px] left-[116px] top-[146px] absolute">
        <div data-layer="home" data-node-id="77-80" className="Home left-[30px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">home</div>
        <div data-layer="lucide/house" data-node-id="77-81" className="LucideHouse w-6 h-5 left-0 top-[5px] absolute overflow-hidden">
          <img data-layer="Vector" data-node-id="77-82" className="Vector w-[18px] h-[15.83px] left-[3px] top-[1.67px] absolute" src="/77-82.svg" />
        </div>
      </div>
      <div data-layer="Group 17" data-node-id="77-83" className="Group17 w-[370px] h-[46px] left-[1025px] top-[50px] absolute">
        <div data-layer="Component 1" data-node-id="77-84" className="Component1 w-[140px] h-[46px] left-0 top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I77-84;5:60" className="Rectangle2 w-[140px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I77-84;5:61" className="Entrar left-[46px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Entrar</div>
        </div>
        <div data-layer="Component 2" data-node-id="77-85" className="Component2 w-[223px] h-[46px] left-[147px] top-0 absolute">
          <div data-layer="Rectangle 2" data-node-id="I77-85;5:60" className="Rectangle2 w-[223px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
          <div data-layer="Entrar" data-node-id="I77-85;5:61" className="Entrar left-[73.27px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Cadastrar</div>
        </div>
      </div>
    </div>
  </div>
  <div data-layer="COMO FUNCIONA?" data-node-id="9-21" className="ComoFunciona w-[1440px] h-[1024px] left-[6791px] top-[5901px] absolute bg-[#f1f8ff] overflow-hidden">
    <div data-layer="Rectangle 1" data-node-id="9-22" className="Rectangle1 w-[1440px] h-[206px] left-0 top-0 absolute bg-[#c4dffd]" />
    <div data-layer="Group 3" data-node-id="9-23" className="Group3 w-[570.75px] h-[75.14px] left-[36px] top-[40px] absolute">
      <div data-layer="Group 2" data-node-id="9-24" className="Group2 w-[455.15px] h-[67.95px] left-[115.59px] top-[5.78px] absolute">
        <div data-layer="PAINEL DE OCUPAÇÃO DE SALAS" data-node-id="9-25" className="PainelDeOcupaODeSalas left-0 top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">PAINEL DE OCUPAÇÃO DE SALAS</div>
        <div data-layer="UNIFEI - Itabira" data-node-id="9-26" className="UnifeiItabira left-[1.46px] top-[34.72px] absolute justify-start text-[#084b91] text-[15px] font-semibold font-['Poppins']">UNIFEI - Itabira</div>
      </div>
      <img data-layer="WhatsApp_Image_2026-09-21_at_23.53.31__1_-removebg-preview 1" data-node-id="9-27" className="WhatsappImage20260921At2353311RemovebgPreview1 w-[96.81px] h-[75.14px] left-0 top-0 absolute" src="/9-27.webp" />
    </div>
    <div data-layer="Group 5" data-node-id="12-155" className="Group5 w-[90px] h-[30px] left-[116px] top-[154px] absolute">
      <div data-layer="home" data-node-id="12-156" className="Home left-[30px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">home</div>
      <div data-layer="lucide/house" data-node-id="12-157" className="LucideHouse w-6 h-5 left-0 top-[5px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="12-158" className="Vector w-[18px] h-[15.83px] left-[3px] top-[1.67px] absolute" src="/12-158.svg" />
      </div>
    </div>
    <div data-layer="objetivo" data-node-id="9-29" className="Objetivo left-[494px] top-[154px] absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">objetivo</div>
    <div data-layer="Group 7" data-node-id="12-161" className="Group7 w-[109px] h-[30px] left-[468px] top-[154px] absolute">
      <div data-layer="objetivo" data-node-id="12-162" className="Objetivo left-[26px] top-0 absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">objetivo</div>
      <div data-layer="hugeicons:goal" data-node-id="12-163" className="HugeiconsGoal w-6 h-6 left-0 top-[3px] absolute overflow-hidden">
        <img data-layer="Group" data-node-id="12-164" className="Group w-4 h-[15px] left-[4px] top-[4px] absolute" src="/12-164.svg" />
      </div>
    </div>
    <div data-layer="como funciona" data-node-id="9-30" className="ComoFunciona left-[864px] top-[154px] absolute justify-start text-[#084b91] text-xl font-semibold font-['Poppins']">como funciona</div>
    <div data-layer="Group 8" data-node-id="9-85" className="Group8 w-[180px] h-[30px] left-[838px] top-[154px] absolute">
      <div data-layer="como funciona" data-node-id="9-86" className="ComoFunciona left-[26px] top-0 absolute justify-start text-[#2882da] text-xl font-semibold font-['Poppins']">como funciona</div>
      <div data-layer="basil:location-question-solid" data-node-id="9-87" className="BasilLocationQuestionSolid w-[26px] h-[26px] left-0 top-[2px] absolute overflow-hidden">
        <img data-layer="Vector" data-node-id="9-88" className="Vector w-[17.89px] h-[21.85px] left-[4.06px] top-[1.63px] absolute" src="/9-88.svg" />
      </div>
    </div>
    <div data-layer="Group 17" data-node-id="23-299" className="Group17 w-[370px] h-[46px] left-[1018px] top-[57px] absolute">
      <div data-layer="Component 1" data-node-id="23-300" className="Component1 w-[140px] h-[46px] left-0 top-0 absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-300;5:60" className="Rectangle2 w-[140px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-300;5:61" className="Entrar left-[46px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Entrar</div>
      </div>
      <div data-layer="Component 2" data-node-id="23-301" className="Component2 w-[223px] h-[46px] left-[147px] top-0 absolute">
        <div data-layer="Rectangle 2" data-node-id="I23-301;5:60" className="Rectangle2 w-[223px] h-[46px] left-0 top-0 absolute bg-[#2882da] rounded-[10px]" />
        <div data-layer="Entrar" data-node-id="I23-301;5:61" className="Entrar left-[73.27px] top-[11px] absolute justify-center text-white text-[15px] font-bold font-['Poppins']">Cadastrar</div>
      </div>
    </div>
  </div>
  <div data-layer="#2882DA" data-node-id="4-17" className="2882da left-[2506px] top-[6324px] absolute justify-start text-black text-xl font-normal font-['Inter']">#2882DA</div>
  <div data-layer="#87C1FF" data-node-id="4-18" className="87c1ff left-[2509px] top-[6425px] absolute justify-start text-black text-xl font-normal font-['Inter']">#87C1FF</div>
  <div data-layer="#C4DFFD" data-node-id="4-21" className="C4dffd left-[2500px] top-[6526px] absolute justify-start text-black text-xl font-normal font-['Inter']">#C4DFFD</div>
  <div data-layer="#F1F8FF" data-node-id="4-24" className="F1f8ff left-[2500px] top-[6617px] absolute justify-start text-black text-xl font-normal font-['Inter']">#F1F8FF</div>
  <div data-layer="Nome do site, títulos, cabeçalho, texto de destaque" data-node-id="5-36" className="NomeDoSiteTTulosCabeAlhoTextoDeDestaque left-[2666px] top-[6224px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Nome do site, títulos, cabeçalho, texto de destaque</div>
  <div data-layer="Botões, links, ícones ativos, item selecionado" data-node-id="5-37" className="BotEsLinksConesAtivosItemSelecionado left-[2682px] top-[6318px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Botões, links, ícones ativos, item selecionado</div>
  <div data-layer="Bordas, ícones secundários, detalhes decorativos" data-node-id="5-41" className="BordasConesSecundRiosDetalhesDecorativos left-[2682px] top-[6419px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Bordas, ícones secundários, detalhes decorativos</div>
  <div data-layer="Fundo de cards, linhas de tabela alternadas, tags" data-node-id="5-42" className="FundoDeCardsLinhasDeTabelaAlternadasTags left-[2684px] top-[6523px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Fundo de cards, linhas de tabela alternadas, tags</div>
  <div data-layer="Fundo geral da página, fundo de campos de busca" data-node-id="5-43" className="FundoGeralDaPGinaFundoDeCamposDeBusca left-[2682px] top-[6614px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">Fundo geral da página, fundo de campos de busca</div>
  <div data-layer="#1A2B3C" data-node-id="5-45" className="1a2b3c left-[2491px] top-[6718px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">#1A2B3C</div>
  <div data-layer="texto comum das tabelas e parágrafos," data-node-id="5-48" className="TextoComumDasTabelasEParGrafos left-[2682px] top-[6718px] absolute justify-start text-black text-xl font-semibold font-['Poppins']">texto comum das tabelas e parágrafos,</div>
</div>
  )
}
